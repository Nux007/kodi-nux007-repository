# -*- coding: utf-8 -*-
import xbmc, xbmcgui  
from resources import lStr, lSettings, addon

from resources.lib import superfavourites
from resources.lib.EPGCtl import EPGGridView
from resources.lib.objects.EpgXml import EpgXml
from resources.lib.objects.EpgDb import EpgDbHandler
from resources.lib.objects.Windows import GlobalSidedWindow
from resources.lib.helpers.logger import SfxLogger

logger = SfxLogger("resources")

'''
Global class handling EPG Gui.
'''
class XMLWindowEPG(xbmcgui.WindowXML):
    
    epgView = None
    can_refresh = True
         
    def __init__(self, strXMLname, strFallbackPath):
        xbmcgui.WindowXML.__init__(self, strXMLname, strFallbackPath, 'default', '720p', False)
        
     
    ''' Gui values init. '''
    def onInit(self):        
        logger.info("EPG View: Loading Grid started")
        if self.can_refresh: 
            self.epgView = EPGGridView(self)  
        logger.info("EPG View: Loading Grid finished")
           
            
    '''
    Handle all xbmc action messages.
    '''
    def onAction(self, action): 
        logger.info("Addon.py received onAction(self, action) : %s", xbmcgui.Action.getId(action))
        logger.debug("Can refresh = %s" % str(self.can_refresh))
        if action in [xbmcgui.ACTION_PREVIOUS_MENU, xbmcgui.ACTION_NAV_BACK]:
            self.epgView.is_closing = True
            xbmc.sleep(1000)
            self.epgView.close()
            del self.epgView
            self.close() 
        
        if self.can_refresh:
            # Grid classic actions
            if action == xbmcgui.ACTION_MOVE_LEFT :
                self.epgView.previousProgram()            
            elif action == xbmcgui.ACTION_MOVE_RIGHT:
                self.epgView.nextProgram()
            elif action in [xbmcgui.ACTION_MOVE_UP, xbmcgui.ACTION_MOUSE_WHEEL_UP]:
                self.epgView.previousChannel()
            elif action in [xbmcgui.ACTION_MOVE_DOWN, xbmcgui.ACTION_MOUSE_WHEEL_DOWN]:
                self.epgView.nextChannel()
        else:
            self.can_refresh = True
                
                      

    ''' Handle all controls clicks, provide a control ID '''
    def onClick(self, controlID):
        logger.info("Addon.py received onClick(self, controlID) : %s", controlID)
        program = self.epgView.getProgram(controlID)
        
        if not program is None:
            sidedWindow = GlobalSidedWindow('global-sided-window.xml', lSettings.getAddonPath())
            sidedWindow.setChannel(self.epgView.getCurrentChannel())
            sidedWindow.setProgram(program)
            sidedWindow.setParent(self)
            sidedWindow.doModal()
            del sidedWindow

        
       
       
    ''' Handle focuses changes between controls '''
    def onFocus(self, controlID):
        logger.info("Addon.py received onFocus(self, controlID) : %s", controlID)
        if self.epgView.isProgramControl(controlID) and self.can_refresh:
            self.epgView.setInfos(controlID) 




''''''''''''''''''''''''''''''
'''    Plugin entry point. '''
''''''''''''''''''''''''''''''

if __name__ == '__main__': 
    
    # Checking lock state.
    from resources.lib.updaters.update import Updates
    if Updates.isLocked():
        from xbmcgui import Dialog
        Dialog().ok(lStr.DIALOG_TITLE, lStr.DB_LOCKED_DATABASE, "", "")
    else:
       
        # Checking for bad configuration.   
        ok, error_msg = lSettings.checkMandatorySettings()
        if not ok:
            logger.info("SFX - bad configuration")
            xbmcgui.Dialog().ok(lStr.DIALOG_TITLE, lStr.BAD_ADDON_CONFIGURATION, error_msg.encode("utf-8", "ignore"), lStr.CONFIGURATION_TAKE_TIME_MSG)
            addon.openSettings()
        
        else:      
            dbHandler = EpgDbHandler()
            
            # Populate and create tables in case of first start
            if dbHandler.isFirstTimeRuning():
                logger.info("First time running detected")
                xbmcgui.Dialog().ok(lStr.DIALOG_TITLE, lStr.SFX_FIRST_START_DETECTED)
                epgXml = EpgXml(dbHandler, progress_bar=True)
                
                if epgXml.getXMLTV():
                    logger.info("Addon.py - Entering getXMLTV()")
                    dbHandler.setFirstTimeRuning(0)
                    Updates.setUpdateDate(dbHandler)
                    xbmc.sleep(1000)
                    # Super favourites folder init.
                    logger.info("Creating SF sub folders")
                    sf_folder = superfavourites.SuperFavouritesIptvFolder()
                    
                    if lSettings.autoCreateSFFolders():
                        sf_folder.createSubFolders()
                    
                    # All is done, restart required
                    xbmcgui.Dialog().ok(lStr.DIALOG_TITLE, lStr.SFX_INIT_OK)
                else:
                    logger.error("Addon.py - getXMLTV() returned False")
                    xbmcgui.Dialog().ok(lStr.DIALOG_TITLE, lStr.XMLTV_LOAD_ERROR)
                
                dbHandler.close()
                epgXml.close()
                del epgXml
                       
            # Else, update epg in a thread
            else:
                logger.info("Addon.py - Gui starting")
                dbHandler.close()
                # Starting GUI
                EPGgui = XMLWindowEPG('epg.xml', lSettings.getAddonPath())
                EPGgui.doModal()
                logger.info("Addon.py - Gui exiting")
                del EPGgui   