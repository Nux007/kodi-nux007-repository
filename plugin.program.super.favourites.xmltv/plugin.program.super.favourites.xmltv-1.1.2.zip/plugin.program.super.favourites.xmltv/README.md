# Kodi-Super-Favourites-Xmltv
Cette addon fourni un mapping entre vos liens IPTV marqu�s avec Super Favourites , et votre fichier XMLTV fourni en param�tres, veuillez bien lire ce document avant toute installation / utilisation.

Pour toute informmation sur l'installation / la configuration / l'utilisation de cette addon, rendez vous sur le Wiki du projet : 
[Wiki SFX](https://github.com/Nux007/Kodi-Super-Favourites-Xmltv/wiki) ( en cours de r�dation ).

## Installation
Si vous souhaitez installer Super Favourites XMLTV, il est pr�f�rable d'installer notre repository, vous pourrez b�n�ficier automatiquement de la derni�re version de l'addon, ainsi que de toutes les mises �jour.

Le repository contenant l'addon peut �tre t�l�charg� ici: 
[kodi.nux007.repository-0.0.2.zip](https://github.com/Nux007/kodi-nux007-repository/blob/master/nux007.repository/nux007.repository-0.0.2.zip)

## Fonctionnalit�s
* Lit votre fichier XMLTV et l'affiche sous forme d'un EPG simple d'utilisation.
* Cr�e automatiquement les sous r�pertoires des chaines dans le dossier Super Favourites de votre choix ( il ne reste plus qu'a ajouter les liens dans les bons r�pertoires )
* T�l�charge les logos des chaines à partir du fichier XMLTV.
* Permet la navigation entre les diff�rents programmes t�l�
* Permet de charger la chaine cible directement depuis l'EPG, si le lien ne fonctionne plus, choisissez simplement le lien suivant dans votre liste ( disponible directement depuis l'EPG )
* Vous notifie des programmes que vous avez marqu�s "Me rappeler"
* Mise � jour automatique du guide ( utile depuis une source internet )
* Suppression automatique des programmes plus vieux
* Choix du nombre de chaines à afficher
* Choix de la taille de la timeline
* Modification du nom des chaines depuis l'interface utilisateur
* Possibilit� de masquer les chaines depuis l'interface utilisateur
* Possibilit� de modifier le logo depuis l'interface utilisateur
* Configuration du background et autres
* Modification timezone � partir de la configuration

## Screenshots
[![SFX Images](https://github.com/Nux007/kodi-nux007-repository/blob/master/plugin.program.super.favourites.xmltv/resources/screenshot-1.png)](https://github.com/Nux007/kodi-nux007-repository/blob/master/plugin.program.super.favourites.xmltv/resources/screenshot-1.png)

[![SFX Images](https://github.com/Nux007/kodi-nux007-repository/blob/master/plugin.program.super.favourites.xmltv/resources/screenshot-2.png)](https://github.com/Nux007/kodi-nux007-repository/blob/master/plugin.program.super.favourites.xmltv/resources/screenshot-2.png)

[![SFX Images](https://github.com/Nux007/kodi-nux007-repository/blob/master/plugin.program.super.favourites.xmltv/resources/screenshot-3.png)](https://github.com/Nux007/kodi-nux007-repository/blob/master/plugin.program.super.favourites.xmltv/resources/screenshot-3.png)

## Installation et Configuration ( Vid�o )
[![Video d'installation et configuration](http://img.youtube.com/vi/tOSudiUsm9Q/0.jpg)](https://youtu.be/tOSudiUsm9Q)

## Contribuer
Toute contribution est la bienvenue, sentez vous libre de cloner / forker le repository Super Favourites XMLTV, d'ajouter des fonctionnalit�s, de corriger les fichiers de langues, de corriger ou am�liorer le code, d'ajouter de nouvelles langues, ... bref, ce repository est libre... A vous de jouer

## Reporter un bug
Tout bug ou demande d'am�lioration, de modification, etc... peut �tre soumis directement dans l'espace 'issues' du projet, voici le lien :

[Soumettre un bug](https://github.com/Nux007/Kodi-Super-Favourites-Xmltv/issues)

## Faire un don
Tout don est le bienvenu et est toujours une motivation pour am�liorer / d�velopper de nouvelles addons, chacun est libre de choisir le montant de son don et est libre de donner ou de ne pas donner, voici le lien Paypal pour ceux qui souhaitent participer financi�rement :
[Faire un don Paypal](https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=HPVUFHX73MKDE&lc=BE&item_name=Nux007&currency_code=EUR&bn=PP%2dDonationsBF%3abtn_donateCC_LG%2egif%3aNonHosted)

## Merci!

Merci d'avance � tous nos g�n�reux contributeurs et donateurs.
