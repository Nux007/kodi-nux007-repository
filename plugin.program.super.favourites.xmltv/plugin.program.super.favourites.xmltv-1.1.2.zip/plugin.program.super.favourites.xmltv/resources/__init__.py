# -*- coding: utf-8 -*-
import os, sys
import xbmc
from xbmcaddon import Addon
import logging

path = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))
path = os.path.join(path, "resources")

sys.path.insert(0, path)

from resources.language import strings
from resources.lib.helpers import settings
from resources.lib.helpers import files
from resources.lib.helpers import xmltv
from resources.lib.helpers import dates
from resources.lib.helpers import guiutils

from resources.lib.objects.EpgXml import EpgXml

addon = Addon('plugin.program.super.favourites.xmltv')

''' local strings and local settings '''
lStr = strings.AddonStrings(addon) 
lSettings = settings.AddonSettings()

''' Addon consts used for readibility '''
aConst = settings.AddonConst()