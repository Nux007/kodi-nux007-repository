# -*- coding: utf-8 -*-


class AddonStrings():
    
    def __init__(self, plugin):
    
        self.DIALOG_TITLE         = plugin.getLocalizedString(31001)
        
        # Settings -> Toolbox actions feedback
        self.HARD_RESET_OK           = plugin.getLocalizedString(300011)
        self.HARD_RESET_NOK          = plugin.getLocalizedString(300012)
        self.HARD_RESET_FOLDERS_OK   = plugin.getLocalizedString(300013)
        self.HARD_RESET_REMINDERS_OK = plugin.getLocalizedString(300014)
        
        # Database messages
        self.DB_CONNECTION_ERROR        = plugin.getLocalizedString(300001)
        self.DB_CREATE_TABLES_ERROR     = plugin.getLocalizedString(300002)
        self.DB_STATE_ERROR             = plugin.getLocalizedString(300003)
        self.DB_CHANNELS_TRUNCATE_ERROR = plugin.getLocalizedString(300004)
        self.DB_PROGRAMS_TRUNCATE_ERROR = plugin.getLocalizedString(300005)
        self.DB_LOCKED_DATABASE         = plugin.getLocalizedString(300006)
        
        # Progress bars.
        self.SF_SUBFOLDERS_PROGRESS_HEADER = plugin.getLocalizedString(300021)
        self.SF_SUBFOLDERS_PROGRESS_MSG    = plugin.getLocalizedString(300022)
        self.SF_CHANNELS_INFOS_ERROR       = plugin.getLocalizedString(300023)    
        self.SF_DIR_STRING                 = plugin.getLocalizedString(300024)
        self.SFX_EPG_UPDATE_HEADER         = plugin.getLocalizedString(300025)
        self.SFX_DOWNLOADING_MSG           = plugin.getLocalizedString(300026)
        self.SFX_LONG_TIME_MSG             = plugin.getLocalizedString(300027)
        self.SFX_ICONS_DOWNLOAD            = plugin.getLocalizedString(300030)
        self.SFX_PROGRAMS_CLEANUP_HEADER   = plugin.getLocalizedString(300031)
        self.SFX_PROGRAMS_CLEANUP          = plugin.getLocalizedString(300032)
        
        # Zip / Tar archives and http downloads.
        self.HTTP_DOWNLOAD_ERROR   = plugin.getLocalizedString(3000311)
        self.ARCHIVE_NO_XMLTV_FOUND       = plugin.getLocalizedString(300044)
        
        # Updates / install / cleanup
        self.REGISTER_UPDATE_ERROR       = plugin.getLocalizedString(300051)
        self.LAST_UPDATE_NOT_FOUND       = plugin.getLocalizedString(300052)
        self.CLEANUP_PROGRAMS_ERROR      = plugin.getLocalizedString(300053)
        self.BAD_XMLTV_FILE_TYPE         = plugin.getLocalizedString(300054)
        self.XMLTV_FILE_NOT_FOUND        = plugin.getLocalizedString(300055)
        self.XMLTV_LOAD_ERROR            = plugin.getLocalizedString(300056)
        self.XMLTV_NO_URL_PROVIDED       = plugin.getLocalizedString(300057)
        self.XMLTV_NO_FILE_PROVIDED      = plugin.getLocalizedString(300058)
        self.NO_SUPER_FAVOURITES_FOLDER  = plugin.getLocalizedString(300059)
        self.BAD_ADDON_CONFIGURATION     = plugin.getLocalizedString(3000510)
        self.CONFIGURATION_TAKE_TIME_MSG = plugin.getLocalizedString(3000511)
        self.SFX_FIRST_START_DETECTED    = plugin.getLocalizedString(3000512)
        self.SFX_INIT_OK                 = plugin.getLocalizedString(3000513)
        
        
        # EPG Data
        self.GET_CHANNELS_ERROR         = plugin.getLocalizedString(300061)
        self.GET_CHANNEL_PROGRAMS_ERROR = plugin.getLocalizedString(300062)        
        self.ADDING_PROGRAM_ERROR       = plugin.getLocalizedString(300066)
        self.GET_CHANNEL_ERROR          = plugin.getLocalizedString(300067)
        self.ADDING_CHANNEL_ERROR       = plugin.getLocalizedString(3000610)
        self.PROGRAM_NO_INFOS           = plugin.getLocalizedString(3000611)
        
        # Edit window actions
        self.ACTIONS_QUIT_WINDOW     = plugin.getLocalizedString(40001)
        self.ACTIONS_RENAME_CHANNEL  = plugin.getLocalizedString(40002)
        self.ACTIONS_DELETE_CHANNEL  = plugin.getLocalizedString(40003)
        self.ACTIONS_EDIT_CHANNEL    = plugin.getLocalizedString(40004)
        self.ACTIONS_LOGO_UPDATE     = plugin.getLocalizedString(40005)
        self.ACTIONS_PROGRAM_START   = plugin.getLocalizedString(40006)
        self.ACTIONS_PROGRAM_REMIND  = plugin.getLocalizedString(40007)
        self.ACTIONS_PROGRAM_LABEL   = plugin.getLocalizedString(40008)
        self.EDIT_LOGO_HEADER        = plugin.getLocalizedString(40011)
        self.EDIT_LOGO_ERROR         = plugin.getLocalizedString(40012)
        self.ACTIONS_PROGRAM_FORGET_REMIND = plugin.getLocalizedString(40017)
        self.NOTIFY_PROGRAM_HEADER   = plugin.getLocalizedString(40019)
        self.NOTIFY_WILL_START_ON    = plugin.getLocalizedString(40020)
        self.ACTIONS_SELECT_STREAM   = plugin.getLocalizedString(40021)
        self.ACTIONS_NO_LINKS_FOUND  = plugin.getLocalizedString(40022)
        self.ACTIONS_EDIT_CHANNEL    = plugin.getLocalizedString(40023)
        self.ACTIONS_DELETE_CONFIRM  = plugin.getLocalizedString(40024)
        self.RESTART_NEEDED          = plugin.getLocalizedString(40025)

