# -*- coding: utf-8 -*-
import os, xbmc
from resources.lib.helpers import settings
from resources.lib.objects.EpgDb import EpgDbHandler
from resources.lib.objects.Programs import Programs
from resources.language import strings
from xbmcaddon import Addon

lStr = strings.AddonStrings(Addon('plugin.program.super.favourites.xmltv')) 
lSettings = settings.AddonSettings()

"""
Handle channels methods
"""
class Channels(object):
    
    def __init__(self, limit):
        self.current_channel_id = 0
        self.limit = limit
    
    
    ''' Truncate the channels table '''
    @staticmethod
    def truncate():
        dbHandler = EpgDbHandler()
        res = dbHandler.requestAndCommit("DELETE FROM channels", error_msg=lStr.DB_CHANNELS_TRUNCATE_ERROR)
        dbHandler.close()
        return True if not res is False else False
    
    
    
    ''' Add a channel definition into the database '''
    @staticmethod
    def addList(clist):
        dbHandler = EpgDbHandler()
        req = "INSERT INTO channels (id_channel, display_name, logo, visible) VALUES (?,?,?,?)"
        data = []
        for channel in clist:
            data.append( (channel[0],channel[1],channel[2], 1) )
        
        res = dbHandler.requestAndCommitMany(req, data, lStr.ADDING_CHANNEL_ERROR )
        dbHandler.close()
        return True if not res is False else False
    
    
    
    ''' Return True if channel exists '''
    @staticmethod
    def exists(id_channel):
        dbHandler = EpgDbHandler()
        res = dbHandler.fetchOne('SELECT count(*) as count FROM channels WHERE id_channel="%s"' % id_channel, lStr.GET_CHANNEL_ERROR)
        dbHandler.close()
        return res[0] == 1 if not res is False else False
    
    
    '''
    Return all available channels
    '''
    @staticmethod
    def getAll():
        dbHandler = EpgDbHandler()
        res = dbHandler.fetchAll('SELECT id FROM channels WHERE visible="1" ORDER BY id ASC', error_msg=lStr.GET_CHANNELS_ERROR)
        channels = []
        for channel_line in res:
            channels.append(Channel(db_id=channel_line[0]))
        dbHandler.close()
        return channels
    
    
    ''' Return top x channels based on last fetched channel_id '''
    def getNextChannels(self):
            dbHandler = EpgDbHandler()
            if self.current_channel_id >= self.limit: 
                req = "SELECT * FROM channels WHERE visible = 1 AND id > %i ORDER BY id ASC LIMIT %i" % (self.current_channel_id, self.limit)
            else:
                req = "SELECT * FROM channels WHERE visible = 1 ORDER BY id ASC LIMIT %i" % self.limit
            
            res = dbHandler.fetchAll(req)
            channels_list = self.__build_list(res)
            dbHandler.close()
            return channels_list
    
    
    ''' Return pevious y channels bsed on last fetched ones '''
    def getPreviousChannels(self):
            dbHandler = EpgDbHandler()
            if self.current_channel_id -lSettings.getDisplayChannelsCount() < 0:
                return self.getNextChannels()
            
            req =  "SELECT id FROM channels WHERE id < %i AND visible = 1 ORDER BY id DESC LIMIT %i" % (self.current_channel_id, lSettings.getDisplayChannelsCount())
            xbmc.log(req, xbmc.LOGERROR)
            res = dbHandler.fetchAll(req)
            channels_list = self.__build_list(res)
            dbHandler.close()
            return channels_list[::-1]
        
    
    ''' Build the channel list '''   
    def __build_list(self, res):
        channels_list = []
        for chan in res:
            channels_list.append(Channel(db_id=chan[0]))
        
        return channels_list
        
        
    ''' Set the current channel id while surfing '''
    def setCurrentChannelId(self, cid):
        self.current_channel_id = cid
    
    
    
    
class Channel(object):
    
    
    def __init__(self, db_id=None, id_channel=None):
        
        self.programs = None
        self.db_id = None
        
        if db_id or id_channel:
            self.__populateFromDb(db__id=db_id, id__channel=id_channel)   
         
    
    
    ''' Return the db id '''
    def getDbId(self):
        return self.db_id
    
    
    ''' Return the display name '''
    def getDisplayName(self):
        return self.display_name
    
    
    ''' Return the EPG id '''
    def getEpgId(self):
        return self.epg_id
    
    
    ''' Return the local logo path '''
    def getLogo(self):        
        try:
            logo = "" if self.logo is None or not lSettings.useXMLTVSourceLogos() else os.path.join(lSettings.getChannelsLogoPath(), self.logo)
        except AttributeError:
            logo = ""
        return logo
        
    
    ''' Return the source if any ( future '''
    def getSource(self):
        return "" if self.source is None else self.source
    
    
    ''' Return true id channel is visible '''
    def isVisible(self):
        return self.enabled
    
    
    ''' Set the db id '''
    def setDbId(self, db_id):
        self.db_id = db_id
         
    
    ''' Set the epg ID '''
    def setEpgId(self, epg_id):
        self.epg_id = epg_id
    
    
    ''' Set the channel enabled or not '''
    def setHidden(self, hidden=False):
        self.enabled = False if hidden else True
    
    
    ''' Set the channel display name '''
    def setDisplayName(self, display_name):
        self.display_name = display_name
    
    
    ''' Set the channel logo '''
    def setLogo(self, logo):
        self.logo = logo
        
    
    ''' Set the logo mode and return the logo ode current vaue '''   
    def isCustomLogo(self, custom = None):
        if custom is None:
            try:
                return self.is_custom_logo
            except AttributeError:
                return False
        else:
            self.is_custom_logo = custom
            return custom
    
    
    ''' Set the channel source '''
    def setSource(self, source):
        self.source = source
    
     
    ''' Return the channels programs as a list of Program object '''
    def getPrograms(self, start=None, stop=None):
        return Programs.getPrograms(self.getDbId(), start, stop)
    
    
    ''' Delete the channel from database '''
    def delete(self):
        dbHandler = EpgDbHandler()
        res = dbHandler.requestAndCommit("DELETE FROM channels WHERE id=%d" % self.getDbId())
        dbHandler.close()
        return not res is False
    
    
    
    ''' Update this channel and send data inside database '''
    def update(self, delete_programs=False):
        if self.getDbId() is None or self.getEpgId() is None:
            return False
            
        req = 'UPDATE channels set id_channel="%s", display_name="%s", logo="%s", source="%s", visible=%d, custom_logo=%d WHERE id=%d'
        dbHandler = EpgDbHandler()
        res = dbHandler.requestAndCommit(req % (self.getEpgId(), self.getDisplayName(), self.getLogo(), self.getSource(), 1 if self.isVisible() else 0, 1 if self.isCustomLogo() else 0, self.getDbId()))
        
        # Dleting programs is visible is set to 0
        if not self.isVisible() and delete_programs:
            req = 'DELETE FROM programs WHERE channel="%s"'
            dbHandler.requestAndCommit(req % self.getEpgId())
            
        dbHandler.close()
        return not res is False
        
    
    
    ''' Populate this object with custom data 
       data format {"db_id": did, "epg_id": eid, "display_name": dname, "logo" : logo, "source" : src, "enabled" : True | False}
    '''
    def populate(self, data = None):
        if data is None or not "db_id" in data:
            return False
        try:
            self.setDbId(data["db_id"])
            self.setEpgId(data["epg_id"])
            self.setDisplayName(data["display_name"])
            self.setLogo(data["logo"])
            self.setSource("" if data["source"] is None else data["source"])
            self.setHidden(False if data["enabled"] else False)
            self.isCustomLogo(custom=False)
            return True
        except AttributeError:
            return False
        
        
    
    ''' Populate channel object from database, default behavior ) '''
    def __populateFromDb(self, db__id = None, id__channel = None):
        
        dbHandler = EpgDbHandler()
        
        if not id__channel is None:
            req = 'SELECT * FROM channels WHERE id_channel="%s"' % id__channel
        else:
            req = "SELECT * FROM channels WHERE id=%d" % db__id
        
        cdata = dbHandler.fetchOne(req)
        
        if not cdata is False:
            self.setDbId(cdata[0])
            self.setEpgId(cdata[1])
            self.setDisplayName(cdata[2])
            self.setLogo(cdata[3])
            self.setSource("" if cdata[4] is None else cdata[4])
            self.setHidden(True if str(cdata[5]) == '0' else False)
            self.isCustomLogo(custom = True if cdata[6] == '1' else False)
        dbHandler.close()
    
    
    
    
    
    
    