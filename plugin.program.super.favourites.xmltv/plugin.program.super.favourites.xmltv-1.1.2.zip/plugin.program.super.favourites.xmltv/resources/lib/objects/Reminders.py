# -*- coding: utf-8 -*-

from xbmcaddon import Addon
from resources.lib.helpers import settings, dates
from resources.lib.objects.EpgDb import EpgDbHandler
from resources.language import strings
from resources.lib.helpers.logger import SfxLogger
from threading import Thread, Timer
import xbmc
    

lStr = strings.AddonStrings(Addon('plugin.program.super.favourites.xmltv')) 
lSettings = settings.AddonSettings()

logger_lib_objects = SfxLogger("resources.lib.objects")


class Reminders(object):
    
    def __init__(self):
        pass
    
    ''' Return all available remindrs '''
    @staticmethod
    def getRemiders(program=None):
        dbHandler = EpgDbHandler()
        resulted = []
        if program is None:
            # Return all reminders.dbHandler = EpgDbHandler()
            rmds = dbHandler.fetchAll("SELECT * FROM reminders")
        else:
            # Return given program related remiders.
            rmds = dbHandler.fetchAll('SELECT * FROM reminders WHERE id_program=%i' % program)
         
        for reminder in rmds:
            resulted.append(Reminder(id_reminder=reminder[0]))
        
        dbHandler.close()
        return resulted
        
    
    ''' Cleanup outdated reminders '''
    @staticmethod
    def cleanup():
        dbHandler = EpgDbHandler()
        rmds = dbHandler.fetchAll("SELECT * FROM reminders")
        
        for reminder in rmds:
            exists = dbHandler.fetchOne("SELECT count(*) FROM programs WHERE id_program=%i" % reminder[1])       
            exists = True if int(exists[0]) > 0 else False
            
            rm = Reminder()
            rm.populate(reminder[1])
            
            # Checking if program exists and if start date is not outdated.
            if not exists or rm.getStartDate() < dates.now():
                rm.delete()
                del rm
            
        dbHandler.close()
        
        
        
    ''' Return True if a remind were added for the targeted id_program '''
    @staticmethod
    def hasReminder(id_program):
        dbHandler = EpgDbHandler()
        res = dbHandler.fetchOne("SELECT count(*) FROM reminders WHERE id_program=%i" % id_program)
        dbHandler.close()
        return True if int(res[0]) > 0 else False
    
    
    
    '''Removes a reminder from the database.'''
    @staticmethod
    def removeReminder(id_program):
        dbHandler = EpgDbHandler()
        res = dbHandler.requestAndCommit("DELETE FROM reminders WHERE id_program=%i" % id_program)
        dbHandler.close()
        return True if not res is False else False
        
        
    
    
"""
Handle a reminder object.
"""
class Reminder(object):
    
    id_program = None
    id_reminder = None
    
    ''' Init and populate reminder '''
    def __init__(self, id_reminder=None):
        if not id_reminder is None:
            self.id_reminder = id_reminder
            self.__populate()
    
    
    ''' Delete current reminder from database'''
    def delete(self):
        dbHandler = EpgDbHandler()
        dbHandler.requestAndCommit("DELETE FROM reminders WHERE id=%i" % self.id_reminder)
        dbHandler.close()
        
    
    ''' Save the current reminder '''
    def save(self):
        if self.id_reminder is None:
            dbHandler = EpgDbHandler()
            req = 'INSERT INTO reminders (id_program) VALUES (%i)' % self.getProgramId()
            dbHandler.requestAndCommit(req)
            dbHandler.close()
        
    
    ''' Retur the start date '''   
    def getStartDate(self):
        return False if self.start_date is None else dates.strToDatetime(self.start_date)
    
    
    ''' Return the channel display name attached to this reminder '''
    def getChannelDisplayName(self):
        return "" if self.channel_display_name is None else self.channel_display_name
    
    
    ''' Return the program id attached to this reminder '''
    def getProgramId(self):
        return self.id_program
    
    
    ''' Return the program title '''
    def getProgramTitle(self):
        return "" if self.program_title is None else self.program_title
    
    
    ''' Notify a program reinder '''
    def notify(self):
        header = (lStr.NOTIFY_PROGRAM_HEADER).encode("utf-8", "ignore")
        message = (self.getProgramTitle() + " " + (lStr.NOTIFY_WILL_START_ON).encode("utf-8", "ignore") + " " + self.getChannelDisplayName())
        xbmc.executebuiltin("Notification(" + header + "," + message + ", 8000, " + lSettings.getAddonIcon() + ")")


        
    ''' Internal populate id id_reminder was provded '''
    def __populate(self):
        # Populate start_date, channl_display name and the program title.
        dbHandler = EpgDbHandler()
        if self.id_program is None:
            res = dbHandler.fetchOne("SELECT id_program FROM reminders WHERE id=%i" % self.id_reminder)
            self.id_program = res[0]
            
        if self.id_reminder is None:
            res = dbHandler.fetchOne("SELECT id FROM reminders WHERE id_program=%i" % self.id_program)
            self.id_reminder = res[0] if not res is None else None
            
        r = 'SELECT channel, title, start_date FROM programs WHERE id_program=%i' % self.getProgramId() 
        res = dbHandler.fetchOne(r)
        if not res is False:
            self.program_title = res[1]
            channel_id = res[0]
            self.start_date = res[2]
            
            r = 'SELECT display_name FROM channels WHERE id_channel="%s"' % channel_id
            res = dbHandler.fetchOne(r)
            self.channel_display_name = res[0]
    
        dbHandler.close()
        
    
    ''' Populate object if id_program was provided '''
    def populate(self, id_program):
        if self.id_reminder is None:
            self.id_program = id_program
            self.__populate()




'''
Handle the threaded programs notifier.
'''
class ThreadedReminderNotifier(Thread):
   
    ''' Init '''
    def __init__(self):
        Thread.__init__(self)
        
    
    ''' Thread run '''
    def run(self):
        try:
            self.startNotifier()
        except Exception as e:
            logger_lib_objects.error(e, exc_info=True)
    
    
    ''' Start notifier '''
    def startNotifier(self, timer=True):
        # Cleanup reminders.
        Reminders.cleanup()
        reminders = Reminders.getRemiders()
        delta = lSettings.getRemindersTime()
        
        for reminder in reminders:            
            if reminder.getStartDate() + delta >= dates.now() and reminder.getStartDate() <= dates.now() + delta:
                # Then notify it and delete record
                reminder.notify()
                reminder.delete()
                xbmc.sleep(12000)
                 
        if timer:
            Timer(4, self.startNotifier, {timer: not xbmc.abortRequested}).start()
        