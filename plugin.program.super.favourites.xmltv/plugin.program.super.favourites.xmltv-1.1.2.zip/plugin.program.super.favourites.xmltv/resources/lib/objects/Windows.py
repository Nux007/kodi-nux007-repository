# -*- coding: utf-8 -*-
from resources import lStr, lSettings
import xbmcgui, os
from xbmc import translatePath
from os.path import join
from uuid import uuid4
from shutil import copy2 as copy
from resources.lib.objects.EpgDb import EpgDbHandler
from resources.lib.superfavourites import SuperFavouritesXMLDialog
from resources.lib.helpers.guiutils import GlobalSidedWindowControls, ChannelEditControls, notify
from resources.lib.helpers import dates
from resources.lib.objects.Reminders import Reminders, Reminder
from resources.lib.helpers.settings import AddonConst


'''
Edit channel popup window
'''
class GlobalSidedWindow(xbmcgui.WindowXMLDialog):

    parent = None
    win_sf   = None
        
    def __init__(self, strXMLname, strFallbackPath):       
        xbmcgui.WindowXML.__init__(self, strXMLname, strFallbackPath, default='Default', defaultRes='720p', isMedia=True)
        
    
    ''' Window init. '''
    def onInit(self):
        self.parent.can_refresh = False
        xbmcgui.WindowXMLDialog.onInit(self)
        
        self.getControl(GlobalSidedWindowControls.PROGRAM_LABEL).setLabel(lStr.ACTIONS_PROGRAM_LABEL + "[CR]" + (self.program.getTitle()).decode("utf-8"))
        self.getControl(GlobalSidedWindowControls.QUIT).setLabel(lStr.ACTIONS_QUIT_WINDOW)
        self.getControl(GlobalSidedWindowControls.CHANNEL_EDIT).setLabel(lStr.ACTIONS_EDIT_CHANNEL)
        self.getControl(GlobalSidedWindowControls.PROGRAM_START).setLabel(lStr.ACTIONS_PROGRAM_START)
        self.getControl(GlobalSidedWindowControls.PROGRAM_REMINDER).setLabel(lStr.ACTIONS_PROGRAM_REMIND)
        self.setFocus(self.getControl(GlobalSidedWindowControls.PROGRAM_START))
        
        dbHandler = EpgDbHandler()
        
        program_start = self.program.getStartDate()
        self.getControl(GlobalSidedWindowControls.PROGRAM_REMINDER).setVisible(False if program_start < dates.now() + lSettings.getRemindersTime() else True)
        remind = Reminders.hasReminder(self.program.getDbId())
        if remind:
            self.getControl(GlobalSidedWindowControls.PROGRAM_REMINDER).setLabel(lStr.ACTIONS_PROGRAM_FORGET_REMIND)
            
        dbHandler.close()


        
    ''' Sets the target channel id and name '''
    def setChannel(self, channel):
        self.channel = channel
    
    
    ''' Sets the target program id and title '''
    def setProgram(self, program):
        self.program = program
    
    
    ''' Set the parent window '''
    def setParent(self, parentWindow):
        self.parent = parentWindow   
        
        
        
    def onAction(self, action): 
        if action in [xbmcgui.ACTION_PREVIOUS_MENU, xbmcgui.ACTION_NAV_BACK]:
            self.parent.can_refresh = False
            self.close()
    
    
    def onFocus(self, controlID):
        self.parent.can_refresh = False
        
        
        
    ''' Handle clicks actions. '''
    def onClick(self, controlId):
        
        # Close
        if controlId == GlobalSidedWindowControls.QUIT:
            self.parent.can_refresh = False
            self.close()
        
        # Add proogram to reminders list.
        elif controlId == GlobalSidedWindowControls.PROGRAM_REMINDER:
            
            if Reminders.hasReminder(self.program.getDbId()):
                self.getControl(GlobalSidedWindowControls.PROGRAM_REMINDER).setLabel(lStr.ACTIONS_PROGRAM_REMIND)
                Reminders.removeReminder(self.program.getDbId())
            
            else:
                self.getControl(GlobalSidedWindowControls.PROGRAM_REMINDER).setLabel(lStr.ACTIONS_PROGRAM_FORGET_REMIND)
                reminder = Reminder()
                reminder.populate(self.program.getDbId())
                reminder.save()
        
        # Start channel
        elif controlId == GlobalSidedWindowControls.PROGRAM_START:
            super_favourites_window = SuperFavouritesXMLDialog('superfavourites-window.xml', lSettings.getAddonPath())
            super_favourites_window.setParent(self)
            super_favourites_window.setChannel(self.channel)
            super_favourites_window.doModal()
            del super_favourites_window
        
        # Edit channel window
        elif controlId == GlobalSidedWindowControls.CHANNEL_EDIT:
            channel_edit_window = ChannelEditWindow('channel-edit-window.xml', lSettings.getAddonPath())
            channel_edit_window.setChannel(self.channel)
            channel_edit_window.setParent(self.parent)
            channel_edit_window.doModal()
            del channel_edit_window
                
                
                



''' Hndle channel Edit window. '''
class ChannelEditWindow(xbmcgui.WindowXMLDialog):
    
    
    def __init__(self, strXMLname, strFallbackPath):       
        xbmcgui.WindowXML.__init__(self, strXMLname, strFallbackPath, default='Default', defaultRes='720p', isMedia=True)
    
    
    ''' Window init. '''
    def onInit(self):
        xbmcgui.WindowXMLDialog.onInit(self)
        self.getControl(ChannelEditControls.CHANNEL_RENAME).setLabel(lStr.ACTIONS_RENAME_CHANNEL)
        self.getControl(ChannelEditControls.CHANNEL_DELETE).setLabel(lStr.ACTIONS_DELETE_CHANNEL)
        self.getControl(ChannelEditControls.QUIT).setLabel(lStr.ACTIONS_QUIT_WINDOW)
        self.getControl(ChannelEditControls.CHANNEL_LOGO_UPDATE).setLabel(lStr.ACTIONS_LOGO_UPDATE)
        self.getControl(ChannelEditControls.CHANNEL_LABEL).setLabel(self.channel.getDisplayName().decode("utf-8"))
        self.setFocus(self.getControl(ChannelEditControls.CHANNEL_RENAME))
        
                
    
    ''' Sets the target channel '''
    def setChannel(self, channel):
        self.channel = channel
        
    
    
    ''' Set the parent window '''
    def setParent(self, parentWindow):
        self.parent = parentWindow   
        
        
        
    def onAction(self, action): 
        if action in [xbmcgui.ACTION_PREVIOUS_MENU, xbmcgui.ACTION_NAV_BACK]:
            self.close()
    
    
    def onFocus(self, controlID):
        pass
    
        
    ''' Handle clicks actions. '''
    def onClick(self, controlId):   
        
        # Close
        if controlId == ChannelEditControls.QUIT:
            self.close()
                
        # Hide channel from EPG and delete all its programs
        if controlId == ChannelEditControls.CHANNEL_DELETE:
            if xbmcgui.Dialog().yesno("Super favourites XMLTV", lStr.ACTIONS_DELETE_CONFIRM, "", ""):
                self.channel.setHidden(True)
                self.channel.update(delete_programs=True) 
                xbmcgui.Dialog().ok("Super Favourites XMLTV", lStr.RESTART_NEEDED, "", "")
            
            
        # Rename the current channel. 
        elif controlId == ChannelEditControls.CHANNEL_RENAME:
            new_name = xbmcgui.Dialog().input(lStr.ACTIONS_RENAME_CHANNEL, self.channel.getDisplayName())
            
            if not new_name is None or new_name == "":
                # renaming sf directory if 'display names' are used.
                if not lSettings.getSFFoldersPattern() == AddonConst.SF_XMLTV_ID_PATTERN:
                    joined = join(lSettings.getSFFolder(translate=True), self.channel.getDisplayName())
                    if os.path.exists(joined):
                        os.rename(joined, join(lSettings.getSFFolder(translate=True), new_name))
                    else:
                        os.mkdir(join(lSettings.getSFFolder(translate=True), new_name)) 
                    self.titleLabel.setLabel(lStr.ACTIONS_EDIT_CHANNEL + "[CR]" + self.channel.getDisplayName())
                   
                self.channel.setDisplayName(new_name)
                self.channel.update()
                xbmcgui.Dialog().ok("Super Favourites XMLTV", lStr.RESTART_NEEDED, "", "")
                   
        
        # Update channel logo
        elif controlId == ChannelEditControls.CHANNEL_LOGO_UPDATE:
            n_logo = xbmcgui.Dialog().browse(2, lStr.EDIT_LOGO_HEADER, 'files')

            if not n_logo is None:
                name = str(uuid4()) + n_logo[n_logo.rfind(r".") :]
                dest = join(lSettings.getChannelsLogoPath(), name)
            
                try:
                    if n_logo.startswith("special://"):
                        n_logo = translatePath(n_logo)
                    copy(n_logo, dest)
                    self.channel.setLogo(name)
                    self.channel.isCustomLogo(True)
                    self.channel.update()
                    xbmcgui.Dialog().ok("Super Favourites XMLTV", lStr.RESTART_NEEDED, "", "")
                except:
                    if lSettings.DEBUG:
                        notify(lStr.EDIT_LOGO_ERROR)
                    return
    
    