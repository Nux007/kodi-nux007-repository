# -*- coding: utf-8 -*-
from resources.lib.objects.EpgDb import EpgDbHandler
from resources.lib.objects.Reminders import Reminders
from resources.lib.helpers import settings, dates
from resources.language import strings
from xbmcaddon import Addon

lStr = strings.AddonStrings(Addon('plugin.program.super.favourites.xmltv')) 
lSettings = settings.AddonSettings()

"""
Handle Programs methods
"""
class Programs(object):
    
    def __init__(self):
        pass
    
    
    ''' Truncate the programs table '''
    @staticmethod
    def truncate():
        dbHandler = EpgDbHandler()
        res = dbHandler.requestAndCommit("DELETE FROM programs", error_msg=lStr.DB_PROGRAMS_TRUNCATE_ERROR)
        dbHandler.close()
        return True if not res is False else False
    
    
     
    ''' Add a program into the program table '''
    @staticmethod
    def addList(program_list): 
        dbHandler = EpgDbHandler()
        req = 'INSERT INTO programs (channel, title, subtitle, description, categories, rating_system, rating_value, credits, icon, start_date, end_date) VALUES (?,?,?,?,?,?,?,?,?,?,?)' 
        data = []
        for program in program_list:            
            data.append( (program[0], program[1], program[2], program[3], program[4], program[5], program[6], program[7], program[8], program[9], program[10]))
        res = dbHandler.requestAndCommitMany(req, data, error_msg=lStr.ADDING_PROGRAM_ERROR)
        dbHandler.close()
        return True if not res is False else False
    
    
    ''' Return all programs for a given channel '''
    @staticmethod
    def getPrograms(db_id, start, stop):
        dbHandler = EpgDbHandler()
        
        req = 'SELECT DISTINCT * FROM programs WHERE channel=(SELECT id_channel FROM channels WHERE id=%i) AND (( CAST(start_date as INTEGER ) BETWEEN %i AND %i ) OR ( CAST(end_date as INTEGER ) >= %i AND CAST(start_date as INTEGER ) < %i) ) ORDER BY start_date ASC' 
        res = dbHandler.fetchAll(req % ( db_id, int(start.strftime("%Y%m%d%H%M%S")), int(stop.strftime("%Y%m%d%H%M%S")), int(start.strftime("%Y%m%d%H%M%S")), int(stop.strftime("%Y%m%d%H%M%S")) ), error_msg=lStr.GET_CHANNEL_PROGRAMS_ERROR)
        
       
        programs_list = []
        for program in res:
            data = {"db_id": program[0], "epg_channel_id": program[1], "title": program[2], "subtitle": program[3], "description": program[4], 
                    "categories": program[5], "rating_system": program[6], "rating_value": program[7], "credits": program[8], "icon": program[9],
                    "start_date": program[10], "end_date": program[11]}
            p_obj = Program()
            p_obj.populate(data)
            programs_list.append(p_obj) 
        dbHandler.close()
        return programs_list
    
    
    ''' Removes duplicates programs from database. '''
    @staticmethod
    def removeDuplicates():
        dbHandler = EpgDbHandler()
        req = """
              DELETE FROM programs 
                  WHERE id_program IN (
                                        SELECT t1.id_program FROM programs t1 
                                        INNER JOIN programs t2 
                                            WHERE t1.channel = t2.channel 
                                                AND CAST(t1.start_date as INTEGER) = CAST(t2.start_date as INTEGER) 
                                                AND ( CAST(t1.end_date as INTEGER) <= CAST(t2.end_date as INTEGER) 
                                                AND t1.id_program != t2.id_program) 
                                      );
              """ 
        dbHandler.requestAndCommit(req)
        dbHandler.close()
        pass
    
    
    
'''
Read only program object
'''
class Program(object):
    
    def __init__(self, id_program=None):
        # auto populate only if id_program was provided.
        if not id_program is None:
            dbHandler = EpgDbHandler()
            res = dbHandler.fetchOne('SELECT * FROM programs WHERE id_program=%i' )
            if not res is None and not res is False:
                data = {"db_id": res[0], "epg_channel_id": res[1], "title": res[2], "subtitle": res[3], "description": res[4], 
                        "categories": res[5], "rating_system": res[6], "rating_value": res[7], "credits": res[8], "icon": res[9],
                        "start_date": res[10], "end_date": res[11]}
                self.populate(data)
            dbHandler.close() 
    
    
    ''' Return the program db id '''
    def getDbId(self):
        return self.db_id
    
    
    ''' Return the epg channel id '''
    def getEpgChannelId(self):
        return self.epg_channel_id
    
    
    ''' Return the program title '''
    def getTitle(self):
        return lStr.PROGRAM_NO_INFOS if self.title is None or self.title is "" else self.title
    
    
    ''' Return the program subtitle '''
    def getSubtitle(self):
        return "" if self.subtitle is None or self.subtitle is "" else self.subtitle
    
    
    ''' Return the program description '''
    def getDescription(self):
        return lStr.PROGRAM_NO_INFOS if self.description is None or self.description is "" else self.description
    
    
    ''' Return the program category '''
    def getCategories(self):
        return lStr.PROGRAM_NO_INFOS if self.categories is None or self.categories is "" else self.categories
    
    
    ''' Return the program rating system '''
    def getRatingSystem(self):
        return False if self.rating_system is None or self.rating_system is "" else self.rating_system
    
    
    ''' Return the rating value if rating system was defined '''
    def getRatingValue(self):
        return False if self.rating_system is None or self.rating_system is "" else self.rating_value
    
    
    ''' Return the program credits '''
    def getCredits(self):
        return False if self.credits is None or self.credits is "" else self.credits
    
    
    ''' Return the program icon '''
    def getIcon(self):
        return False if self.icon is None or self.icon is "" else self.icon
    
    
    ''' Return the program strt date as datetime '''
    def getStartDate(self):
        return self.start_date
    
    
    ''' Return the program end date as datetime '''
    def getEndDate(self):
        return self.end_date
    
    
    ''' Return all available reminders for the current program '''
    def getReminders(self):
        reminders = Reminders.getRemiders(self.db_id)
        return False if len(reminders) == 0 else reminders
    
    
    ''' Return true if targeted program has ssociated reminders '''
    def hasReminder(self):
        return Reminders.hasReminder(self.db_id)
    
    
    ''' Return true if the program is outdated '''
    def isOutdated(self):
        return self.start_date < dates.now()
    
    
    ''' Populate object with provided data '''
    def populate(self, data):
        
        self.db_id = data["db_id"]
        self.epg_channel_id = data["epg_channel_id"]
        self.title = data["title"]
        self.subtitle = data["subtitle"] 
        self.description = data["description"]
        self.categories = data["categories"]
        self.rating_system = data["rating_system"]
        self.rating_value = data["rating_value"]
        self.credits = data["credits"]
        self.icon = data["icon"]
        self.start_date = dates.strToDatetime(data["start_date"])
        self.end_date = dates.strToDatetime(data["end_date"])
    