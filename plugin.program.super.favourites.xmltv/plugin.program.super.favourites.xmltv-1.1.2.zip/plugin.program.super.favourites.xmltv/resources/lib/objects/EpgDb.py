# -*- coding: utf-8 -*-
import xbmc
from xbmcaddon import Addon
from resources.lib.helpers.logger import SfxLogger
from resources.language import strings
from resources.lib.helpers import settings
from resources.lib.helpers.guiutils import notify

from os.path import isfile
from sqlite3 import connect as SqliteConnect, Error as SqliteError


lStr = strings.AddonStrings(Addon('plugin.program.super.favourites.xmltv')) 
lSettings = settings.AddonSettings()

logger_lib_objects = SfxLogger("resources.lib.objects")


class EpgDbHandler(object):
    
    """
    Handler init
    """
    def __init__(self):
        
        self.database = None
        self.cursor = None
        
        if not isfile(lSettings.getEpgDbFilePath()):
            self.database, self.cursor = self.__connect()
            if self.database is None:
                return None, None
        
            channels_str, programs_str, updates, notifications, lock = lSettings.getTablesStructure()      
            update_flag  = "INSERT INTO updates (time) VALUES ('-1')"
        
            try:
                self.cursor.execute(channels_str)
                self.cursor.execute(programs_str)
                self.cursor.execute(updates)
                self.cursor.execute(update_flag)
                self.cursor.execute(notifications)
                self.cursor.execute(lock)
                self.database.commit()
                
            except SqliteError as e:
                logger_lib_objects.error(e, exc_info=True)
                notify(lStr.DB_CREATE_TABLES_ERROR, e.message)
        else:
            self.__connect()
            
    
    '''
    Return the initialization state.
    '''
    def isDBInitOk(self):
        return True if self.database is not None and self.cursor is not None else False
    
    
        '''
    Set the first time start flag..
    '''
    def setFirstTimeRuning(self, state):
        self.requestAndCommit("UPDATE updates set time ='%s' WHERE id_update=1" % state, error_msg=lStr.DB_STATE_ERROR)
        
        
    
    '''
    Return True if this is the FIRST launch or eĝ.db ad epg.xml were deleted.
    '''
    def isFirstTimeRuning(self):
        res = self.fetchOne("SELECT COUNT(*) as count FROM updates WHERE time='-1'", error_msg=lStr.DB_STATE_ERROR)
        return True if int(res[0]) == 1 else False 
            
        
    """
    Send a request and return back the whole result.
    """   
    def fetchOne(self, query, error_msg=""):
        try:
            self.cursor.execute(query)
            return self.cursor.fetchone()
        except SqliteError as e:
            logger_lib_objects.error(e, exc_info=True)
            if lSettings.DEBUG:
                notify(error_msg, e.message)
            return False
        
    
    """
    Send a request and return back the whole result.
    """   
    def fetchAll(self, query, error_msg=""):
        try:
            self.cursor.execute(query)
            return self.cursor.fetchall()
        except SqliteError as e:
            logger_lib_objects.error(e, exc_info=True)
            if lSettings.DEBUG:
                notify(error_msg, e.message)
            return False
    
    
    """
    Send a request and commit to DB ( used to store or update data).
    """
    def requestAndCommit(self, query, data=None, error_msg=""):
        try:
            if not data is None:
                self.cursor.execute(query, data)
            else:
                self.cursor.execute(query) 
                   
            self.database.commit()
            
        except SqliteError as e:
            logger_lib_objects.error(e, exc_info=True)
            if lSettings.DEBUG:
                notify(error_msg, e.message)
            return False
        
    
    """
    Send a request and commit to DB "many" sqlite.
    """
    def requestAndCommitMany(self, query, data, error_msg=""):
        try:
            self.cursor.executemany(query, data)        
            self.database.commit()
        except SqliteError as e:
            logger_lib_objects.error(e, exc_info=True)
            if lSettings.DEBUG:
                notify(error_msg, e.message)
            return False
        
        
    
    """
    Return the database obj
    """
    def getDatabase(self):
        return self.database
    
    
    """
    Return the cursor obj
    """
    def getCursor(self):
        return self.cursor
    
    
    """ Internal """
    def __connect(self):
        try:
            self.database = SqliteConnect(lSettings.getEpgDbFilePath())
            self.database.text_factory = str
            self.cursor = self.database.cursor()
        except SqliteError as e:
            logger_lib_objects.error(e, exc_info=True)
            notify(lStr.DB_CONNECTION_ERROR, e.message)
            xbmc.log("[ SFX - EpgDb.py ] %s" % e.message, xbmc.LOGERROR)
            return None
        
        return self.database, self.cursor
    
    
    """
    On close, make sure all db objects are closed too.
    """
    def close(self):
        if not self.cursor is None:
            self.cursor.close()
            del self.cursor
        if not self.database is None:
            self.database.close()
            del self.database
        