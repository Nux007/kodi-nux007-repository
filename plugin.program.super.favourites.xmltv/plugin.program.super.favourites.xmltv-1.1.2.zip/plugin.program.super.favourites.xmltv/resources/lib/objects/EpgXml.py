# -*- coding: utf-8 -*-

import os
from glob import glob
from xbmc import sleep
from shutil  import rmtree
from xbmcaddon import Addon

from resources.language import strings
from resources.lib.helpers import settings
from resources.lib.helpers import files, xmltv as xmltv_helper
from resources.lib.helpers.logger import SfxLogger
from resources.lib.helpers.guiutils import notify
from resources.lib.objects.Channels import Channels, Channel
from resources.lib.objects.Programs import Programs

from xbmcgui import DialogProgress, DialogProgressBG

lStr = strings.AddonStrings(Addon('plugin.program.super.favourites.xmltv')) 
lSettings = settings.AddonSettings()
aConst = settings.AddonConst()

logger_lib_objects = SfxLogger("resources.lib.objects")


'''
Handle XMLTV itself.
'''
class EpgXml(object):
            
    def __init__(self, dbHandler, progress_bar=True, update_mode=False): 
        self.dbHandler = dbHandler
        self.update_mode = update_mode
        self.progress_bar = DialogProgress() if progress_bar else DialogProgressBG() 
        self.progress_bar.create(lStr.SFX_EPG_UPDATE_HEADER, "") 
    
    
    '''
    Global entry point to get / parse and push xmltv data into db.
    '''
    def getXMLTV(self):
        
        if not self.dbHandler.isDBInitOk():
            return False
        
        # Removing old epg.xml file.
        if os.path.isfile(lSettings.getEpgXmlFilePath()):
            os.remove(lSettings.getEpgXmlFilePath()) 
            
            
        # Local EPG file handling.
        if  lSettings.getXMLTVSourceType() == aConst.XMLTV_SOURCE_LOCAL:
            self.__getLocalXmltv(lSettings.getXMLTVURLLocal())
        
        # Remote EPG file handling.
        elif lSettings.getXMLTVSourceType() == aConst.XMLTV_SOURCE_URL:    
            result, status = files.download(lSettings.getXMLTVURLRemote(), lSettings.getEpgXmlFilePath(), timeout=60, progress_func=self._download_progress)
            if not status is None and status in [304, 301, 400, 401, 403, 404, 500, 502, 503, 504]:
                notify(lStr.HTTP_DOWNLOAD_ERROR, lSettings.getLocalizedString(status).encode("UTF-8", "ignore"))
            if not result:
                return False
                 
            self.__getLocalXmltv(lSettings.getEpgXmlFilePath())
            
        else:
            return False
        
        return self.__parseXMLTV()
    
    
    
    """
    EPG download progress notifier.
    """
    def _download_progress(self,bytes_so_far, chunk_size, total_size):
        percent = float(bytes_so_far) / total_size
        percent = round(percent*100, 2)
        if not isinstance(self.progress_bar, DialogProgressBG) and self.progress_bar.iscanceled():
            return False
        self.progress_bar.update(int(percent), "[SFX] %s - %d/%d Kb (%0.2f%%)\r" % (lStr.SFX_DOWNLOADING_MSG, int(bytes_so_far/1024), int(total_size/1024), percent), "")
        # Return true to continue listening iscanceled event.
        return True
        
        
    
    """
    EPX xml file parsing hook progress.
    """
    def _parse_xmltv_progress(self, current, total, percent , int_message):
        if not isinstance(self.progress_bar, DialogProgressBG) and self.progress_bar.iscanceled():
            return False
        self.progress_bar.update(int(percent), "[SFX] %s - %d/%d (%0.2f%%)\r" % (lSettings.getLocalizedString(int_message), current, total, percent), "")
        return True
    
            
    
    '''
    Basic xml file checks
    '''
    def __getLocalXmltv(self, local_file):
        if os.path.isfile(local_file):
            if not lSettings.isXMLTVCompressed() and not local_file.endswith(".xml"):
                notify(lStr.BAD_XMLTV_FILE_TYPE)      
            elif not lSettings.isXMLTVCompressed():
                # Moving to userdata
                if not lSettings.getXMLTVSourceType() == aConst.XMLTV_SOURCE_URL:
                    files.copyfile(local_file, lSettings.getEpgXmlFilePath())
            else:
                # Uncompress and moving to userdata
                self.__uncompressAndMove(local_file)
        else:
            notify(lStr.XMLTV_FILE_NOT_FOUND)
            
    
    '''
    Uncompress zip, tar, ... archive and moves it into the right directory.
    '''
    def __uncompressAndMove(self, zfile):
        
        dest = os.path.join(lSettings.getAddonUserDataPath(), "epg.archive")                
        
        result = files.uncompress(zfile, dest)
        if not result:
            notify(lStr.ARCHIVE_NO_XMLTV_FOUND)
            return
        
        if os.path.isdir(dest):
            paths = glob(os.path.join(dest, "*.xml"))
            search = ["data", "epg", "guide", "xml", "xmltv"]
            for s in search:
                if os.path.exists(os.path.join(dest, s)):
                    paths.append(os.path.join(dest, s))
            
            if len(paths) <= 0:
                notify(lStr.ARCHIVE_NO_XMLTV_FOUND)
                rmtree(dest)
                return
            
            for ptest in paths:
                if xmltv_helper.isXmlTv(ptest):
                    if os.path.exists(lSettings.getEpgXmlFilePath()):
                        os.remove(lSettings.getEpgXmlFilePath())
                    os.rename(ptest, lSettings.getEpgXmlFilePath())
                    rmtree(dest)
                    break
        else:
            # This was a gzipped file.
            if os.path.exists(dest):
                if os.path.exists(lSettings.getEpgXmlFilePath()):
                    os.remove(lSettings.getEpgXmlFilePath())
                os.rename(dest, lSettings.getEpgXmlFilePath())
                
                    
    
    '''
    Parse the xmltv file and return the result.
    '''
    def __parseXMLTV(self):
        
        if not os.path.isfile(lSettings.getEpgXmlFilePath()):
            return False
            
        result, clist, plist, icons_list = xmltv_helper.parseXmlTv(lSettings.getEpgXmlFilePath(), 
                                                                   use_epg_timeshift = lSettings.useEpgTimeZone(), 
                                                                   use_custom_timeshift = lSettings.useCustomTimeZone(), 
                                                                   delta = lSettings.getTimeZoneDelta(), 
                                                                   operation = "+" if lSettings.getTimeZoneOperation() == 0 else "-",
                                                                   progress_hook=self._parse_xmltv_progress,
                                                                   )
        
        if not result:
            return False

        for channel in clist:         
            if Channels.exists(channel[0]):
                clist.remove(channel)
        
        # Adding parsed channels.
        Channels.addList(clist)
        
        # Adding parsed programs.
        Programs.truncate()
        Programs.addList(plist)
        Programs.removeDuplicates()
                
        if lSettings.useXMLTVSourceLogos():
            result_icons = self.downloadIcons(icons_list)
            if not result_icons:
                return False
        
        return True
    
    
    ''' 
    Download icons from xmltv source
    '''
    def downloadIcons(self, sources):
        dest_dir = lSettings.getChannelsLogoPath() 
         
        if not os.path.isdir(dest_dir):
            os.mkdir(dest_dir)                  
        i = 1
        for source in sources:
            self.progress_bar.update(int( ( i / float(len(sources)) ) * 100), '[SFX] %s - %i/%i (%i%%)' % (lStr.SFX_ICONS_DOWNLOAD, i, len(sources), int( ( i / float(len(sources)) ) * 100)), "")
            if not isinstance(self.progress_bar, DialogProgressBG) and self.progress_bar.iscanceled():
                return False
            
            if not source is None:
                icon_name = source[source.rfind(r"/") + 1 :]
                dest_file = os.path.join(dest_dir, icon_name)
                
                status = 200
                if self.update_mode:
                    # update mode, do not download all icons, but only update not existing ones.
                    if not os.path.exists(dest_file):
                        result, status = files.download(source, dest_file)
                else:
                    result, status = files.download(source, dest_file)

                if lSettings.DEBUG and status in [304, 301, 400, 401, 403, 404, 500, 502, 503, 504]:
                    logger_lib_objects.info("UNABLE TO DOWLOAD CHANNEL ICON: %s" % source)                    
                    
            i += 1
            sleep(20)
        return True
                        
            
    '''
    Cose the epg_db oject
    '''
    def close(self):
        try:
            self.progress_bar.close()
        except Exception:
            pass
