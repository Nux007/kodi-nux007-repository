# -*- coding: utf-8 -*-
import os
import re
from xml.etree import ElementTree as ET
from resources.lib.helpers import dates
from resources.lib.helpers.logger import SfxLogger
from xbmc import sleep

logger_lib_helpers = SfxLogger("resources.lib.helpers")


"""
Check if the provided xml file is an xmltv file.
"""
def isXmlTv(file):
    if not os.path.isfile(file):
        return False
    try:
        xml = ET.parse(file)
        root = xml.getroot()
        programs = True if len(root.findall('programme')) > 0 else False
                    
        if programs:
            return True
    except Exception as e:
        logger_lib_helpers.error(e, exc_info=True)
        return False
    
    
    
    
"""
Handle xmltv Format
"""
def parseXmlTv(xmltv_file, use_epg_timeshift=True, use_custom_timeshift=False, delta=None, operation="+", progress_hook=None):
    channels_list = [] 
    icons_src_list = []
    programs_list = []
    
    if progress_hook:
        result_hook = progress_hook(33, 100, 33 , 300027)
        if not result_hook:
            return False, None, None, None
    
    xml = ET.parse(xmltv_file)
    root = xml.getroot()
    
    if progress_hook:
        result_hook = progress_hook(66, 100, 66 , 300027)
        if not result_hook:
            return False, None, None, None
    channels = root.findall('channel')
    
    if progress_hook:
        result_hook = progress_hook(90, 100, 90 , 300027)
        if not result_hook:
            return False, None, None, None
    programs = root.findall('programme')
    
    i = 0
    # Getting channels.
    for channel in channels:
        i += 1
        if progress_hook:
            result_hook = progress_hook(i, len(channels), int( i/float(len(channels)) * 100) , 300028)
            sleep(20)
            if not result_hook:
                return False, None, None, None
            
        id_channel   = (channel.get('id')).encode('utf-8', 'ignore') 
        display_name = (channel.find('display-name').text).encode('utf-8', 'ignore')
        display_name = (display_name.replace(r'/', '-')).replace("\\", "-")
        
        try:
            icon = (channel.find("icon").get("src")).encode('utf-8', 'ignore') if not (channel.find("icon").get("src")).encode('utf-8', 'ignore') is None else ""
        except AttributeError:
            icon = ""
            
        if not icon == "":
            icons_src_list.append(icon)
            icon = icon[icon.rfind(r"/") + 1 :] 
                                    
        channels_list.append([id_channel, display_name, icon, '', '1'])
            
    
    i = 0     
    # Getting programs.
    for program in programs:
        
        i += 1
        if progress_hook:
            result_hook = progress_hook(i, len(programs), int( i/float(len(programs)) * 100) , 300029)
            if not result_hook:
                return False, None, None, None
            
        id_channel = (program.get('channel')).encode('utf-8', 'ignore')
        pattern = r"(\d*)\s*(\W)([0-9][0-9])([0-9][0-9])"
        search_start_date = re.search(pattern, (program.get('start')).encode('utf-8', 'ignore'))
        search_end_date   = re.search(pattern, (program.get('stop')).encode('utf-8', 'ignore'))
                        
        start_date = search_start_date.group(1)
        # 14 digits epg time format, some epg files does not use it, we use yyyymmddhhmmss format some epg uses yyyymmddhhmm.
        while len(start_date) < 14:
            start_date = start_date + "0"
            
        end_date = search_end_date.group(1)
        while len(end_date) < 14:
            end_date = end_date + "0"
            
        # Application du timeshift present dans l'EPG fourni.
        if use_epg_timeshift:
            program_start = dates.strToDatetime(start_date, h=search_start_date.group(3), m=search_start_date.group(4), o=search_start_date.group(2))
            program_end   = dates.strToDatetime(end_date, h=search_end_date.group(3), m=search_end_date.group(4), o=search_end_date.group(2)) 
        else:
            program_start = dates.strToDatetime(start_date)
            program_end   = dates.strToDatetime(end_date)
        
        # Application du custom timeshift si fourni.    
        if use_custom_timeshift and not delta is None:
                
            if operation == "+":
                program_start += delta
                program_end += delta
            elif operation == "-":
                program_start -= delta
                program_end -= delta
            
            
        # Fetching most commons programs attributes and tags.
        try:
            ptitle = (program.find('title').text).encode('utf-8', 'ignore')
        except AttributeError:
            ptitle = "No title"
        
        try:
            subtitle = (program.find('sub-title').text).encode('utf-8', 'ignore')
        except AttributeError:
            subtitle = ""
                
        try:
            desc = (program.find('desc').text).encode('utf-8', 'ignore')
        except AttributeError:
            desc = "No description"
        
        try:
            categories = ""
            for category in program.iter('category'):
                categories += (category.text).encode('utf-8', 'ignore') + ", "
            categories = categories[:-2]
        except AttributeError:
            categories = ""
            
        
        try:
            rating_system = program.find("rating")
            rating_value  = (rating_system.find("value").text).encode('utf-8', 'ignore')
            rating_system = (rating_system.get("system")).encode('utf-8', 'ignore')
        except AttributeError:
            rating_system = ""
            rating_value = ""
        
        # Managing credits.
        try:
            credits_tg = program.find("credits")
            credits_list = ""
        except:
            credits_tg = None
        
        if not credits_tg is None:
            credits_tags = ["actor", "director", "editor", "presenter", "writer"]
            t_dict = {}
            
            for tag in credits_tags:
                
                values = ""
                
                try:
                    for value in credits_tg.iter(tag):
                        values += (value.text).encode('utf-8', 'ignore') + ", "
                except AttributeError:
                        values = ""
                        
                if len(values) > 0:
                    values = values[:-2]
                else:
                    values = ""
                
                t_dict[tag] = values
                
            credits_list = str(t_dict)
            
        
        # Managing icons.
        try:
            icon = program.find('icon')
            icon = (icon.get("src")).encode('utf-8', 'ignore')
        except AttributeError:
            icon = ""
            
            
        programs_list.append([id_channel, ptitle, subtitle, desc, categories, rating_system, rating_value, credits_list, icon, 
                              program_start.strftime("%Y%m%d%H%M%S"), program_end.strftime("%Y%m%d%H%M%S")])
              

    return True, channels_list, programs_list, icons_src_list