# -*- coding: utf-8 -*-
from datetime import datetime as dt, timedelta
from time import strptime as time_strptime

'''
Return a datetim from string as %Y%m%d%H%M%S
'''
def strToDatetime(datestr, h=None, m=None, o=None):
    
    def deltaStuff(tm, h=None, m=None, o=None):
        
        if not o is None:       
            if m is None:
                m = 0
            if h is None:
                h = 0
                
            tm_delta = timedelta(hours=int(h), minutes=int(m))
            if o == 0 or o == "+":
                tm += tm_delta
            elif o == 1 or o == "-":
                tm -= tm_delta
        
        return tm
    
    
    try:
        tm = deltaStuff(dt.strptime(datestr, "%Y%m%d%H%M%S"), h, m, o)
    except (TypeError, ValueError):
        tm = deltaStuff(dt(*(time_strptime(datestr, "%Y%m%d%H%M%S")[0:6])), h, m, o)
    
    return tm



"""
datetime.now() bridge.
"""
def now():
    return dt.now()