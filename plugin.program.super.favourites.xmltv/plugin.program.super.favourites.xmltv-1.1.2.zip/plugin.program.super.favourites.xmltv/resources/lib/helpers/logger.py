# -*- coding: utf-8 -*-
import logging
from os.path import join, exists
from os import mkdir
from xbmc import translatePath
from xbmcaddon import Addon

addon = Addon('plugin.program.super.favourites.xmltv')
DEBUG = True if addon.getSetting('debug.mode') == 'true' else False

class SfxLogger(object):
    
    def __init__(self, logger_name):
        
        path = join(translatePath("special://profile/addon_data"), "plugin.program.super.favourites.xmltv")
        if not exists(path):
            mkdir(path)    
        path = join(path, "sfx_log.txt")
        
        self.logger = logging.getLogger(logger_name)
        self.logger.setLevel(logging.DEBUG)
        fHandler = logging.FileHandler(path)
        fHandler.setLevel(logging.DEBUG)
        formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
        fHandler.setFormatter(formatter)
        self.logger.addHandler(fHandler)
            
        self.logger.disabled = True
        if DEBUG:
            # Disable logging if settings DEBUG is set to Fallse.
            self.logger.disabled = False


    def error(self, msg, *args, **kwargs):
        self.logger.error(msg, *args, **kwargs)
        
    
        
    def info(self, msg, *args, **kwargs):
        self.logger.info(msg, *args, **kwargs)
        
        
        
    def debug(self, msg, *args, **kwargs):
        self.logger.debug(msg, *args, **kwargs)