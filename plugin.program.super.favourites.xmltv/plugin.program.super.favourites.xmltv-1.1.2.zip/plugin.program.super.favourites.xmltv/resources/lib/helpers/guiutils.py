# -*- coding: utf-8 -*-
from xbmcaddon import Addon
from xbmcgui import ControlImage
from resources.language import strings
from resources.lib.helpers import settings
from xbmc import executebuiltin, log, LOGERROR
from os.path import join
lStr = strings.AddonStrings(Addon('plugin.program.super.favourites.xmltv')) 
lSettings = settings.AddonSettings()


''' Display a basic notification '''    
def notify(message, plus=None):
    try:
        message = message.encode("utf-8", 'ignore')
    except UnicodeEncodeError:
        pass
        
    log(message, LOGERROR)
    if not plus is None:
        try:
            log(plus, LOGERROR)
        except UnicodeEncodeError:
            log(plus.encode("utf-8", "ignore"), LOGERROR)
        
    executebuiltin('Notification(%s,%s,%s,%s)'%((lStr.DIALOG_TITLE).encode("utf-8", 'ignore'), message, 6000, lSettings.getAddonIcon()))
    



''' Handle the whole Epg positions '''
class EpgPosition(object):
    
    def __init__(self):
        pass
    
    ''' Set the X absis vaue '''
    def setXsurfing(self, x):
        self.x = x
        
    
    ''' Set the y surfing vaue '''
    def setYsurfing(self, y):
        self.y = y
    
    
    ''' Set left position '''
    def setLeft(self, left):
        self.left = left
    
    
    ''' Set right position '''
    def setRight(self, right):
        self.right = right
        
        
    ''' Set bottom position '''
    def setBottom(self, bottom):
        self.bottom = bottom
    
    
    ''' Set top position '''
    def setTop(self, top):
        self.top = top
    
    
    ''' Set width '''
    def setWidth(self, width):
        self.width = width
        
    
    ''' Set cellHeight '''    
    def setCellHeight(self, cellHeight):
        self.cellHeight = cellHeight
    
    
    ''' Set start_time '''
    def setStartTime(self, start_time):
        self.start_time = start_time    
        
    
    ''' Set stop time '''
    def setStopTime(self, stop_time):
        self.stop_time = stop_time
    
    
    ''' Set the current program '''
    def setProgram(self, program):
        self.program = program
    
    
    ''' Set the current channel '''
    def setChannel(self, channel):
        self.channel = channel
        
        
    ''' Return left position '''
    def getLeft(self):
        return self.left
    
    
    ''' Return right position '''
    def getRight(self):
        return self.right
        
        
    ''' Retur bottom position '''
    def getBottom(self):
        return self.bottom
    
    
    ''' Return top position '''
    def getTop(self):
        return self.top
    
    
    ''' Return width '''
    def getWidth(self):
        return self.width
        
    
    ''' Return cellHeight '''    
    def getCellHeight(self):
        return self.cellHeight
    
    
    ''' Return start_time '''
    def getStartTime(self):
        return self.start_time    
        
    
    ''' Return stop time '''
    def getStopTime(self):
        return self.stop_time
    
    
    ''' Return the current program '''
    def getProgram(self):
        return self.program
    
    
    ''' Return the current channel '''
    def getChannel(self):
        return self.channel
    
    
    ''' Return the current x surfing value '''
    def getXsurfing(self):
        return self.x
    
    
    ''' Return the crrent y surfing value '''
    def getYsurfing(self):
        return self.y
    
    
    ''' Inc the x surfing value '''
    def XSurfingIncrement(self):
        self.x += 1
    
    
    ''' Dec the x surfing value '''
    def XSurfingDecrement(self):
        self.x -= 1
        
        
    ''' Inc the y surfing value '''
    def YSurfingIncrement(self):
        self.y += 1
    
    
    ''' Dec the y surfing value '''
    def YSurfingDecrement(self):
        self.y -= 1
    
    
    
    
    
    
''' Hansle splash screen loading image in case of large xmltv files '''
class SplashScreen(object):
    
    def __init__(self, window, position):
        self.window = window
        
        x = int(position.getWidth() / 2) + int(193 / 4)
        y = int(position.getBottom() / 2) + int(192 / 4)
        
        img = join(lSettings.getAddonImagesPath(), "splashscreen", "loading.gif")
        bg = join(lSettings.getAddonImagesPath(), "splashscreen", "splash-bg.png")
        
        self.splash = ControlImage(x, y, int(193 / 2), int(192 / 2), img)
        self.splashBg = ControlImage(0, 0, position.getWidth() * 2, position.getBottom() * 2, bg)
              

    '''
    Display slashscreen
    '''
    def start(self):
        self.window.addControl(self.splashBg)
        self.window.addControl(self.splash)
        
    
    '''
    Removes the splah screen.
    '''
    def stop(self):
        self.window.removeControl(self.splashBg)
        self.window.removeControl(self.splash)
        
        
        
'''
Reference to EPG kodi controls.
'''
class EPGControl(object):
    
    GLOBAL_CONTROL = 5001
    
    '''
    Images references.
    '''
    class image(object):
        BACKGROUND = 4600
        TIME_MARKER = 4100
        CHANNEL_LOGO   = 4031
        
    '''
    Labels references
    '''
    class label(object):
        DATE_TIME_TODAY         = 4000
        DATE_TIME_QUARTER_ONE   = 4001
        DATE_TIME_QUARTER_TWO   = 4002
        DATE_TIME_QUARTER_THREE = 4003
        DATE_TIME_QUARTER_FOUR  = 4004
        
        PROGRAM_TITLE = 4020
        PROGRAM_DESCRIPTION = 4022
        PROGRAM_TIME = 4021
        
        CHANNEL_NAME   = 4030
    
'''
Edit window controls
'''
class GlobalSidedWindowControls(object):
    PROGRAM_START    = 3998
    PROGRAM_REMINDER = 3999
    CHANNEL_EDIT     = 4001     
    QUIT = 4002 
    PROGRAM_LABEL    = 4102
   
    
    
    
class ChannelEditControls(object):
    
    QUIT = 4002
    CHANNEL_DELETE   = 4001
    CHANNEL_RENAME = 4000
    CHANNEL_LOGO_UPDATE = 4003
    CHANNEL_LABEL    = 4102
        