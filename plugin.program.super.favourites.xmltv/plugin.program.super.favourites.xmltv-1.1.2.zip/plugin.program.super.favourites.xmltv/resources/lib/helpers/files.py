# -*- coding: utf-8 -*-
import urllib2, httplib, ssl
import zipfile, tarfile, gzip
import os, shutil
from resources.lib.helpers.logger import SfxLogger

logger_lib_helpers = SfxLogger("resources.lib.helpers")


"""
Handle files downloads
"""
def download(source, target, timeout=30, progress_func=None, headers={'User-Agent': 'Mozilla/5.0'}):

    # Chunk download to attach progress status.
    def chunk_read(response, chunk_size=8192, report_hook=None):
        total_size = response.info().getheader('Content-Length').strip()
        total_size = int(total_size)
        bytes_so_far = 0
        
        tsf = open(target, "wb")
        while 1:
            if chunk_size >= total_size:
                chunk_size = total_size
                
            chunk = response.read(chunk_size)
            tsf.write(chunk)
            bytes_so_far += len(chunk)
        
            if not chunk:
                break

            if report_hook:
                hook_status = report_hook(bytes_so_far, chunk_size, total_size)
                if not hook_status:
                    tsf.close()
                    del tsf
                    return False
        tsf.close()
        del tsf
    
        return bytes_so_far


    # Download file.
    if os.path.isfile(target):
        os.remove(target)
        
    ssl._create_default_https_context = ssl._create_unverified_context
    
    if not source.startswith("http"):
        source = "http:" + source
                    
    req = urllib2.Request(source, headers=headers)
        
    try:
        download = urllib2.urlopen(req, timeout=30)
        result = chunk_read(download, report_hook=progress_func)
        if not result:
            return False, 0
        
    except httplib.BadStatusLine as e:
        source = source.replace("http", "https")
        req = urllib2.Request(source, headers=headers)
        download = urllib2.urlopen(req, timeout=30)
        result = chunk_read(download, report_hook=progress_func)
        if not result:
            return False, 0
                            
    except urllib2.HTTPError as e:
        logger_lib_helpers.error(e, exc_info=True)
        if e.code in [304, 301, 400, 401, 403, 404, 500, 502, 503, 504]:
            return False, e.code
    except timeout:
        logger_lib_helpers.error("files.py download Timout", exc_info=True)
        return False, 504
    except Exception as e:
        if "404" in e.message:
            return False, 404
        
    return os.path.isfile(target), None



"""
Unzip files
"""
def uncompress(source, target):
    if zipfile.is_zipfile(source):
        try:
            with zipfile.ZipFile(source, "r") as zipped:
                zipped.extractall(target)
                zipped.close()
                    
        except (zipfile.BadZipFile, zipfile.LargeZipFile):
            logger_lib_helpers.error("files.py - uncompress ZIP error", exc_info=True)
            if os.path.isdir(target):
                shutil.rmtree(target)    
            return False
            
    elif tarfile.is_tarfile(source):
        try:
            with tarfile.TarFile(source) as tarred:
                tarred.extractall(target)
                tarred.close()
                        
        except tarfile.ReadError:
            logger_lib_helpers.error("files.py - uncompress TAR error", exc_info=True)
            if os.path.isdir(target):
                shutil.rmtree(target)   
            return False
   
    # If not, trying gzip.
    else :
        try:
            gzipped = gzip.GzipFile(source, 'rb')
            buff = gzipped.read()
            gzipped.close()
        
            outF = open(target, 'w')
            outF.write(buff)
            outF.close()
        except Exception:
            logger_lib_helpers.error("files.py - uncompress GZIP error", exc_info=True)
            if os.path.isfile(target):
                os.remove(target)
            return False
        
    return True




'''
Copy a file from source to dest.
'''
def copyfile(source, dest, buffer_size=1024*1024):
    
    source = open(source, "rb")
    destin = open(dest, "wb")
    
    while 1:
        copy_buffer = source.read(buffer_size)
        if not copy_buffer:
            break
        destin.write(copy_buffer)
        
        