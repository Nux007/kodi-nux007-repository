# -*- coding: utf-8 -*-
from resources import lStr, lSettings
import xbmcgui

from os.path import isfile
from datetime import timedelta
from threading import Timer
from xbmc import abortRequested

from resources.lib.helpers.guiutils import EPGControl, EpgPosition, SplashScreen
from resources.lib.helpers import dates
from resources.lib.helpers.logger import SfxLogger
from resources.lib.objects.Channels import Channels
from resources.lib.objects.Reminders import Reminders


logger_lib = SfxLogger("resources.lib")


''' 
Handle View positions.
''' 
class EPGGridView(object):
    
    window = None
    position = EpgPosition()
    channels_utils = None
    channels_list = None
    programs_list = None
    controls = None
   
    is_closing = False    
    loading = None

    
    ''' Defining grid view points. '''
    def __init__(self, window):
        self.window = window
        self.channels_utils = Channels(lSettings.getDisplayChannelsCount())
        
        # Setting top, left, right, bottom, cellHeight values.
        globalControl = self.window.getControl(EPGControl.GLOBAL_CONTROL)
        x, y = globalControl.getPosition()
        self.position.setLeft(x)
        self.position.setTop(y)
        self.position.setRight(self.position.getLeft() + globalControl.getWidth())
        self.position.setBottom(self.position.getTop() + globalControl.getHeight())
        self.position.setWidth(globalControl.getWidth())
        self.position.setCellHeight(int(globalControl.getHeight() / lSettings.getDisplayChannelsCount()))   
        self.position.setXsurfing(0)
        self.position.setYsurfing(0)
        
        # Setting start_time, stop_time, values.
        self.position.setStartTime((dates.now()).replace(minute=(0 if dates.now().minute <= 29 else 30)))
        self.position.setStopTime(self.position.getStartTime() + timedelta(minutes=lSettings.getTimelineToDisplay() - 2))
    
        self.setEPGBackgrounds()
        self.setTimeMarker(timer=True)
        self.setTimesLabels()    
        self.loading = SplashScreen(self.window, self.position)         
        
        self.getAndDisplayChannels()
        self.setFocus(self.position.getXsurfing(), self.position.getYsurfing())     
        self.status = True
    
    
    
    ''' Set the EPG background with customer lSettings '''
    def setEPGBackgrounds(self):
        bg_img = lSettings.getImageBackgroundCustom() if lSettings.useCustomBackground() else lSettings.getImageBackground()
        (self.window.getControl(EPGControl.image.BACKGROUND)).setImage(bg_img, useCache=False) 
        self.window.getControl(EPGControl.image.TIME_MARKER).setImage(lSettings.getImageTimeMarker(), useCache=False)
       
    
    
    ''' Set the time marker position '''
    def setTimeMarker(self, timer=False):
        if self.is_closing:
            return
        delta = dates.now() - self.position.getStartTime()
        (self.window.getControl(EPGControl.image.TIME_MARKER)).setVisible(False)
        
        if delta.seconds >=  0 and delta.seconds <= lSettings.getTimelineToDisplay() * 60:
            (self.window.getControl(EPGControl.image.TIME_MARKER)).setPosition(int(self.secondsToX(delta.seconds)), (self.window.getControl(EPGControl.image.TIME_MARKER)).getY())
            (self.window.getControl(EPGControl.image.TIME_MARKER)).setVisible(True)
                 
        if timer and not abortRequested and not self.is_closing:
            Timer(4, self.setTimeMarker, {timer: True}).start() 
            
    
    
    ''' Seconds from delta to x position '''
    def secondsToX(self, secs):
        return self.position.getLeft() + (secs * self.position.getWidth() / (lSettings.getTimelineToDisplay() * 60)) + 24
            
            
            
    ''' Return the time turned into EPG style '''
    def setTimesLabels(self):
        if self.is_closing:
            return
        
        def __toTimeView(ctime, multiplier):
            # Defining time for program guide and time labels zone.            
            increment = int(lSettings.getTimelineToDisplay() / 4) * multiplier
            later = (ctime + timedelta(minutes=increment)).time()
            return str(("[B]%02d:%02d[/B]") % (later.hour, later.minute))

        #Setting date and time controls.
        self.window.getControl(EPGControl.label.DATE_TIME_QUARTER_ONE).setLabel(__toTimeView(self.position.getStartTime(), 0))
        self.window.getControl(EPGControl.label.DATE_TIME_QUARTER_TWO).setLabel(__toTimeView(self.position.getStartTime(), 1))
        self.window.getControl(EPGControl.label.DATE_TIME_QUARTER_THREE).setLabel(__toTimeView(self.position.getStartTime(), 2))
        self.window.getControl(EPGControl.label.DATE_TIME_QUARTER_FOUR).setLabel(__toTimeView(self.position.getStartTime(), 3))
        
        labelCurrentDate = self.window.getControl(EPGControl.label.DATE_TIME_TODAY)
        labelCurrentDate.setLabel(self.position.getStartTime().strftime("[B]%d/%m/%Y[/B]"))
    
    
    
    ''' Display all current channels '''
    def getAndDisplayChannels(self, previous_channels = False):
        self.loading.start()
        
        if previous_channels:
            logger_lib.info("EPGCtl.py - Getting previous channels")
            self.channels_list = self.channels_utils.getPreviousChannels()
        else:
            logger_lib.info("EPGCtl.py - Getting next channels")
            self.channels_list = self.channels_utils.getNextChannels()
        logger_lib.info("EPGCtl.py - Got %i channels", len(self.channels_list))
        
        
        self.__destroyGrid()        
        self.controls = []
        self.programs_list = []
        
        idx = 0
        for channel in self.channels_list:            
            y = self.position.getTop() + self.position.getCellHeight() * idx + int((self.position.getCellHeight() / 14))
            
            if lSettings.useXMLTVSourceLogos() and not channel.getLogo() is None and not channel.getLogo() is "" and isfile(channel.getLogo()):
                control_channel = xbmcgui.ControlImage(16, y + 2, 170, self.position.getCellHeight() - 8, channel.getLogo(), aspectRatio=2)
            else:
                control_channel = xbmcgui.ControlLabel(16, y + 2, 180, self.position.getCellHeight() - 8, "[B]%s[/B]" % channel.getDisplayName())
            
            self.controls.append( { "channel_control" : control_channel, "programs_controls" :[] } )
                        
                        
            # Program details.
            logger_lib.info("EPGCtl.py - Getting programs for %s", channel.getDisplayName())
            programs = channel.getPrograms(self.position.getStartTime(), self.position.getStopTime())
            logger_lib.info("EPGCtl.py - Got %i programs", len(programs))
            
            if len(programs) == 0:
                
                control_program = xbmcgui.ControlButton(
                    self.position.getLeft(), self.position.getTop() + self.position.getCellHeight() * idx, self.position.getRight() - self.position.getLeft() - 2,
                    self.position.getCellHeight() - 2, lStr.PROGRAM_NO_INFOS, lSettings.getFocusTexture(), lSettings.getNoFocusTexture())
                
                self.controls[idx]["programs_controls"].append(control_program)
                self.programs_list.append( {"control": control_program, "program" : None, "y" : idx} )
                
    
            for program in programs:   
                deltaStart = program.getStartDate() - self.position.getStartTime()
                deltaStop  = program.getEndDate() - self.position.getStartTime()
                
                y = self.position.getTop() + self.position.getCellHeight() * idx
                x = self.secondsToX(deltaStart.seconds) if deltaStart.days >= 0 else self.position.getLeft()
                width = self.secondsToX(deltaStop.seconds) - x
                
                if x + width > self.position.getRight():
                    width = self.position.getRight() - x
                width -= 2
                
                program_title = "" if width < 40 else program.getTitle()
                remind = Reminders.hasReminder(program.getDbId())
                focusTexture = lSettings.getReminderFocusTexture() if remind else lSettings.getFocusTexture()
                noFocusTexture = lSettings.getReminderNoFocusTexture() if remind else lSettings.getNoFocusTexture()
                
                control_program = xbmcgui.ControlButton(x, y, width, self.position.getCellHeight() - 2, program_title, noFocusTexture=noFocusTexture, focusTexture=focusTexture)         
                self.controls[idx]["programs_controls"].append(control_program) 
                self.programs_list.append( {"control": control_program, "program" : program, "y" : idx} )
                
            idx += 1
        
        ctrls_channels = [ctrl["channel_control"] for ctrl in self.controls]    
        ctrls_programs = [program for ctrl in self.controls for program in ctrl["programs_controls"]]
        self.window.addControls(ctrls_channels)
        self.window.addControls(ctrls_programs)
        
        # And setting focus to the first grid element.
        self.loading.stop()
        
        
        
    ''' Setfocus on control that has y and x values inside the grid '''    
    def setFocus(self, x, y):
        self.window.setFocus(self.controls[y]["programs_controls"][x])
    
        
        
    '''Go to the next program control or next page.'''
    def nextProgram(self):
        if len(self.controls[self.position.getYsurfing()]["programs_controls"]) - 1 == self.position.getXsurfing():
            # Load new page
            delta = timedelta(minutes=lSettings.getTimelineToDisplay())
            self.position.setStopTime(self.position.getStopTime() + delta)
            self.position.setStartTime(self.position.getStartTime() + delta)
            self.getAndDisplayChannels()  
            self.setTimesLabels()
            self.position.setXsurfing(0)
        else:
            # Next control
            self.position.XSurfingIncrement()
        self.setFocus(self.position.getXsurfing(), self.position.getYsurfing())
            
            
            
    '''Go to the previous control or previous page.'''
    def previousProgram(self):
        if self.position.getXsurfing() == 0:
            delta = timedelta(minutes=lSettings.getTimelineToDisplay())
            self.position.setStopTime(self.position.getStopTime() - delta)
            self.position.setStartTime(self.position.getStartTime() - delta)
            self.getAndDisplayChannels() 
            self.setTimesLabels()
            self.position.setXsurfing(len(self.controls[self.position.getYsurfing()]["programs_controls"]) - 1)
        else:
            self.position.XSurfingDecrement()
        
        self.setFocus(self.position.getXsurfing(), self.position.getYsurfing())
            
    
    
    ''' Load the next channels list '''    
    def nextChannel(self):
        
        if len(self.controls) - 1 == self.position.getYsurfing():
            self.getAndDisplayChannels()
            self.position.setXsurfing(0)
            self.position.setYsurfing(0)
        else:
            self.position.setXsurfing(0)
            self.position.YSurfingIncrement()
        
        self.channels_utils.setCurrentChannelId((self.channels_list[self.position.getYsurfing()]).getDbId())
        self.setFocus(self.position.getXsurfing(), self.position.getYsurfing())    
        
        
        
    ''' Load previous channels '''
    def previousChannel(self):
        if self.position.getYsurfing() == 0:
            self.getAndDisplayChannels(previous_channels=True)
            self.position.setXsurfing(0)
            self.position.setYsurfing(len(self.controls) - 1)
        else:
            self.position.YSurfingDecrement()
            self.position.setXsurfing(0)
        
        self.channels_utils.setCurrentChannelId((self.channels_list[self.position.getYsurfing()]).getDbId())    
        self.setFocus(self.position.getXsurfing(), self.position.getYsurfing())
            
    
    
    ''' Set the current program infos '''
    def setInfos(self, controlID):
        # Getting program infos.
        program = None
        for control in self.programs_list:
            if controlID == control["control"].getId():
                program = control["program"]
                
                # Mouse controls changes support.
                for i in range(len(self.controls[control["y"]]["programs_controls"]) -1):
                    if self.controls[control["y"]]["programs_controls"][i].getId() == controlID:
                        self.position.setYsurfing(control["y"])
                        self.position.setXsurfing(i)
                        self.channels_utils.setCurrentChannelId(self.channels_list[self.position.getYsurfing()].getDbId())
                
     
        title = "Aucun titre" if program is None else program.getTitle()
        description = "Aucune description" if program is None else program.getDescription()
        time = "Pas d'info" if program is None else "[B]%s - %s[/B]" % (program.getStartDate().strftime("%H:%M"), program.getEndDate().strftime("%H:%M"))
        
        self.window.getControl(EPGControl.label.PROGRAM_TITLE).setLabel("[B]%s[/B]" % title)     
        self.window.getControl(EPGControl.label.PROGRAM_DESCRIPTION).setText(description)
        self.window.getControl(EPGControl.label.PROGRAM_TIME).setLabel(time)    
        
        # The above space whill be used for new tags.
        #self.window.getControl(EPGControl.label.CHANNEL_NAME).setLabel("[B]Catégories:[/B][CR]%s" % program.getCategories())
        #self.window.getControl(EPGControl.image.CHANNEL_LOGO).setImage(logo, False)
    
    
    
    ''' Return prorgam based on its controID as Program'''
    def getProgram(self, controlID):
        program = None
        for control in self.programs_list:
            if controlID == control["control"].getId():
                program = control["program"]
        return program
    
    
    ''' Return the current pointed channel as Channel '''
    def getCurrentChannel(self):
        return self.channels_list[self.position.getYsurfing()]
                
                
    
    ''' Return true id the provided control is inside the cnotrol grid '''
    def isProgramControl(self, control_id):
        return self.window.getControl(control_id) in [program for ctrl in self.controls for program in ctrl["programs_controls"] ]
    
    
    

    ''' Destroy / remove all components '''
    def close(self):
        try:
            self.is_closing = True
            self.__destroyGrid()
            #Setting date and time controls.
            self.window.removeControl(self.window.getControl(EPGControl.label.DATE_TIME_QUARTER_ONE))
            self.window.removeControl(self.window.getControl(EPGControl.label.DATE_TIME_QUARTER_TWO))
            self.window.removeControl(self.window.getControl(EPGControl.label.DATE_TIME_QUARTER_THREE))
            self.window.removeControl(self.window.getControl(EPGControl.label.DATE_TIME_QUARTER_FOUR))
            self.window.removeControl(self.window.getControl(EPGControl.label.DATE_TIME_TODAY))
            self.window.removeControl(self.window.getControl(EPGControl.image.BACKGROUND))
            self.window.removeControl(self.window.getControl(EPGControl.image.TIME_MARKER))
            del self.loading
            del self.channels_list
            del self.channels_utils
            del self.controls
            del self.programs_list
        except:
            pass
    
    
    
    ''' Destroy the grid components '''
    def __destroyGrid(self):
        # Removing existing contrls first
        if not self.controls is None and len(self.controls) > 0:
            self.window.removeControls([ctrl["channel_control"] for ctrl in self.controls])
            self.window.removeControls([program for ctrl in self.controls for program in ctrl["programs_controls"]])
            
            
            
            