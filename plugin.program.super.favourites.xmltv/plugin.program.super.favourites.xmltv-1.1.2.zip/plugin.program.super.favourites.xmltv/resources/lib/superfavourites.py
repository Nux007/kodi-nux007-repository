# -*- coding: utf-8 -*-
import xbmcgui
import xbmc
import re
from resources import lStr, lSettings, aConst, addon

from os import mkdir
from os.path import join, exists
from xbmcgui import DialogProgress
from xml.dom import minidom

from resources.lib.helpers.guiutils import notify
from resources.lib.helpers.logger import SfxLogger
from resources.lib.objects.EpgDb import EpgDbHandler

logger_lib = SfxLogger("resources.lib")


'''
Handle Super favourites iptv subfolders.
'''
class SuperFavouritesIptvFolder(object):
                 
    '''
    Init
    '''
    def __init__(self):
        self.dbHandler = EpgDbHandler()    
     
    '''
    Create the base subfolders structure.
    '''
    def createSubFolders(self):
        progress = DialogProgress()
        
        progress.create(lStr.SF_SUBFOLDERS_PROGRESS_HEADER, lStr.SF_SUBFOLDERS_PROGRESS_MSG)
        row = "id_channel" if lSettings.getSFFoldersPattern() == aConst.SF_XMLTV_ID_PATTERN else 'display_name' 
        request = "SELECT %s FROM channels" % row
        
        if self.dbHandler.getDatabase() is None or self.dbHandler.getCursor() is None:
            notify(lStr.SF_CHANNELS_INFOS_ERROR)
            progress.close()
            return
        
        channels = self.dbHandler.fetchAll(request, error_msg=lStr.SF_CHANNELS_INFOS_ERROR)
        
        i = 1
        for channel in channels:
            
            if not exists(join(lSettings.getSFFolder(translate=True), channel[0])):
                try:
                    mkdir(join(lSettings.getSFFolder(translate=True), channel[0]))
                except OSError as e:
                    logger_lib.error(e, exc_info=True)
                
            progress.update(int( ( i / float(len(channels)) ) * 100), "", 
                            lStr.SF_DIR_STRING + ' %i/%i' % (i, len(channels)))
            i += 1
       
        progress.close()   
            
        
    '''
    Return the subfolder of given iptv channel.
    '''
    def getSubFolderLinks(self, id_channel):
        # Getting pattern
        channel_data = []
        row = "id_channel" if lSettings.getSFFoldersPattern() == aConst.SF_XMLTV_ID_PATTERN else "display_name"
        res = self.dbHandler.fetchOne('SELECT %s FROM channels WHERE id=%d' % (row, id_channel))
        if res is False:
            return []
        pattern = res[0]
        
        sf_folder = join(xbmc.translatePath(lSettings.getSFFolder()), pattern)
        
        if exists(sf_folder):
            # linked stored inside SF/channel/faourites.xml ( containing all channels links )
            xml_file = join(sf_folder, "favourites.xml")
            if exists(xml_file):
                xml = minidom.parse(xml_file)
                links = xml.getElementsByTagName("favourite")
                
                for link in links:
                    link_name   = link.getAttribute("name")
                    link_action = link.firstChild.nodeValue
                    channel_data.append({"name":link_name, "action":link_action})
                return channel_data
            else:
                channel_data
        else:
            # The referenced folder points to an addon folder, so getting SF command
            xml_file = join(xbmc.translatePath(lSettings.getSFFolder()), "favourites.xml")
            xml = minidom.parse(xml_file)
            sf_commands = xml.getElementsByTagName("favourite")
            
            for action in sf_commands:
                if action.getAttribute("name") == pattern:
                    link_action = action.firstChild.nodeValue
                    channel_data.append({"name":"Open SF folder", "action":link_action})
                return channel_data 
        
        
        
class SuperFavouritesXMLDialog(xbmcgui.WindowXMLDialog):
    
    sfiptv = None
    iptv_links = []
    container = None
    
    ADDON   = addon
    ADDONID = 'plugin.program.super.favourites.xmltv'
    PLAYMEDIA_MODE      = 1
    ACTIVATEWINDOW_MODE = 2
    RUNPLUGIN_MODE      = 3
    ACTION_MODE         = 4
    
    '''
    Init
    '''
    def __init__(self, strXMLname, strFallbackPath):
        xbmcgui.WindowXML.__init__(self, strXMLname, strFallbackPath, default='Default', defaultRes='720p', isMedia=True)
    
    
    '''
    On init
    '''
    def onInit(self):
        self.container = self.getControl(50)
        self.getControl(5000).setLabel(lStr.ACTIONS_SELECT_STREAM)
        self.getControl(5001).setLabel(lStr.ACTIONS_QUIT_WINDOW)
        self.sfiptv = SuperFavouritesIptvFolder()
        self.iptv_links = self.sfiptv.getSubFolderLinks(self.channel.getDbId())
        
        
        if not self.iptv_links is None and len(self.iptv_links) == 0 :
            self.getControl(50).setVisible(False)
            self.getControl(5000).setLabel(lStr.ACTIONS_NO_LINKS_FOUND)
        else:
            self.container.reset()
            for link in self.iptv_links: 
                item = xbmcgui.ListItem(label=link["name"], iconImage=self.channel.getLogo())
                self.container.addItem(item)
        
        self.parent.close()
        del self.parent
        
    ''' Set the channel ID '''
    def setChannel(self, channel):
        self.channel = channel
        
    
    ''' On window action '''   
    def onAction(self, action):
        if action in [xbmcgui.ACTION_PREVIOUS_MENU, xbmcgui.ACTION_NAV_BACK]:
            self.container.reset()
            self.close() 
        
        if action in [xbmcgui.ACTION_MOVE_LEFT, xbmcgui.ACTION_MOVE_RIGHT, ]:
            self.setFocus(self.getControl(5001))
        
        if action == xbmcgui.ACTION_SELECT_ITEM:
            itemPos = self.container.getSelectedPosition()
            if itemPos is not None and itemPos != -1:
                self.playCommand(self.iptv_links[itemPos]["action"])


    
    ''' Set the parent windows '''
    def setParent(self, parent):
        self.parent = parent

                
    
    '''
    On controls clicks
    '''
    def onClick(self, controlId):
        if controlId == 5001:
            self.container.reset()
            self.close()
        
        


    def removeSFOptions(self, cmd):
        if 'sf_options=' not in cmd:
            return cmd

        cmd = cmd.replace('?sf_options=', '&sf_options=')

        cmd = re.sub('&sf_options=(.+?)_options_sf"\)', '")',               cmd)
        cmd = re.sub('&sf_options=(.+?)_options_sf",return\)', '",return)', cmd)
        cmd = re.sub('&sf_options=(.+?)_options_sf',    '',                 cmd)

        cmd = cmd.replace('/")', '")')

        return cmd


    def tidy(self, cmd):
        cmd = cmd.replace('&quot;', '')
        cmd = cmd.replace('&amp;', '&')
        cmd = self.removeSFOptions(cmd)
    
        if cmd.startswith('RunScript'):
            cmd = cmd.replace('?content_type=', '&content_type=')
            cmd = re.sub('/&content_type=(.+?)"\)', '")', cmd)
    
        if cmd.endswith('/")'):
            cmd = cmd.replace('/")', '")')
    
        if cmd.endswith(')")'):
            cmd = cmd.replace(')")', ')')
    
        return cmd
    


    def playCommand(self, originalCmd, contentMode=False):
        try:    
            cmd = self.tidy(originalCmd)
    
            #if in contentMode just do it
            if contentMode:
                xbmc.executebuiltin('ActivateWindow(Home)') #some items don't play nicely if launched from wrong window
                if cmd.lower().startswith('activatewindow'):
                    cmd = cmd.replace('")', '",return)') #just in case return is missing                
                return xbmc.executebuiltin(cmd)  
    
            if 'ActivateWindow' in cmd:
                return self.activateWindowCommand(cmd) 
    
            if 'PlayMedia' in cmd:
                return self.playMedia(originalCmd)
    
            if cmd.lower().startswith('executebuiltin'):
                try:    
                    cmd = cmd.split('"', 1)[-1]
                    cmd = cmd.rsplit('")')[0]
                except:
                    pass
    
            xbmc.executebuiltin(cmd)


        except Exception:
            pass   




    def activateWindowCommand(self, cmd):
        cmds = cmd.split(',', 1)
    
        #special case for filemanager
        if '10003' in cmds[0] or 'filemanager' in cmds[0].lower():
            xbmc.executebuiltin(cmd)
            return   
    
        plugin   = None
        activate = None
    
        if len(cmds) == 1:
            activate = cmds[0]
        else:
            activate = cmds[0]+',return)'
            plugin   = cmds[1][:-1]
    
        #check if it is a different window and if so activate it
        ids = str(xbmcgui.getCurrentWindowId())    
    
        if ids not in activate:
            xbmc.executebuiltin(activate)
    
        if plugin: 
            xbmc.executebuiltin('Container.Update(%s)' % plugin)


    def getSFOptions(self, cmd):
        import urllib 
    
        try:    options = urllib.unquote_plus(re.compile('sf_options=(.+?)_options_sf').search(cmd).group(1))
        except: return {}
    
        return self.get_params(options)
    
    

    def getOption(self, cmd, option):
        options = self.getSFOptions(cmd)
    
        try:    return options[option]
        except: return ''


    def playMedia(self, original): 
        cmd = self.tidy(original).replace(',', '') #remove spurious commas
        
        try:    mode = int(self.getOption(original, 'mode'))
        except: mode = 0
    
        if mode == self.PLAYMEDIA_MODE:       
            xbmc.executebuiltin(cmd)
            return
    
        plugin = re.compile('"(.+?)"').search(cmd).group(1)
    
        if len(plugin) < 1:
            xbmc.executebuiltin(cmd)
            return
    
        if mode == self.ACTIVATEWINDOW_MODE:   
            try:    winID = int(self.getOption(original, 'winID'))
            except: winID = 10025
    
            #check if it is a different window and if so activate it
            ids = xbmcgui.getCurrentWindowId()
    
            if ids != winID :
                xbmc.executebuiltin('ActivateWindow(%d)' % winID)
                
            cmd = 'Container.Update(%s)' % plugin
    
            xbmc.executebuiltin(cmd)
            return
    
        if mode == self.RUNPLUGIN_MODE:
            cmd = 'RunPlugin(%s)' % plugin
    
            xbmc.executebuiltin(cmd)
            return
    
        #if all else fails just execute it
        xbmc.executebuiltin(cmd)  
        
        
    def get_params(self, p):
        param=[]
        paramstring=p
        if len(paramstring)>=2:
            params=p
            cleanedparams=params.replace('?','')
            if (params[len(params)-1]=='/'):
                params=params[0:len(params)-2]
            pairsofparams=cleanedparams.split('&')
            param={}
            for i in range(len(pairsofparams)):
                splitparams={}
                splitparams=pairsofparams[i].split('=')
                if (len(splitparams))==2:
                    param[splitparams[0]]=splitparams[1]
        return param  
        
        
    