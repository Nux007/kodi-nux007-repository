# -*- coding: utf-8 -*-
from resources import lStr, lSettings
from threading import Thread
from time import time
from datetime import datetime
import _strptime
from xbmc import sleep

from resources.lib.objects.EpgXml import EpgXml
from resources.lib.objects.EpgDb import EpgDbHandler
from resources.lib.helpers import dates
from resources.lib.helpers.logger import SfxLogger

logger_lib_updaters = SfxLogger("resources.lib.updaters")

  
'''
Handle threaded updates
''' 
class ThreadedEPGUpdater(Thread):
    
    ''' Thread init '''
    def __init__(self):
        Thread.__init__(self)
    
    
    ''' Thread run '''
    def run(self):
        try:      
            dbHandler = EpgDbHandler()
            sleep(lSettings.getTimeSleep())
            if dbHandler.isFirstTimeRuning():
                dbHandler.close()
                return
            
            # Getting last update date.
            update_date = Updates.getLastUpdateDate(dbHandler) 
            current_time = datetime.fromtimestamp(time())
            
            update_time=0
            if not update_date is False:
                update_time = dates.strToDatetime(update_date)
                delta = current_time - update_time
                        
            if update_date is False or delta.days >= lSettings.getUpdateFrequency() :        
            
                epg_xml = EpgXml(dbHandler, progress_bar=False, update_mode=True)
                epg_xml.getXMLTV()
                Updates.setUpdateDate(dbHandler)
                    
                epg_xml.close() 
                del epg_xml
                
            Updates.getCleanOld(dbHandler)
            dbHandler.close()
        except Exception as e:
            logger_lib_updaters.error(e, exc_info=True)



'''
Handle updates related tasks.
'''
class Updates(object):
    
    def __init__(self):
        pass
   
   
    ''' Delete all outdated programs '''
    @staticmethod
    def getCleanOld(dbHandler, hook=None, sender=None): 
        res = dbHandler.fetchAll("SELECT id_program, end_date FROM programs", error_msg=lStr.CLEANUP_PROGRAMS_ERROR)
        i = 0
        data = []
        for program in res:
            i += 1
            delta = datetime.now() - dates.strToDatetime(program[1])
                    
            if delta.days >= lSettings.getCleanupTreshold() :
                data.append( (program[0],) )
        
            if not hook is None:
                percent = float(i) / len(res)
                percent = round(percent*100, 2)
                hook(percent, sender)
                        
        if len(data) > 0:
            dbHandler.requestAndCommitMany("DELETE FROM programs WHERE id_program=?", data, error_msg=lStr.CLEANUP_PROGRAMS_ERROR)
            
                
        
    ''' Return last update date '''
    @staticmethod
    def getLastUpdateDate(dbHandler):
        if dbHandler.isDBInitOk():
            res = dbHandler.fetchOne("SELECT time FROM updates WHERE 1 ORDER BY id_update DESC LIMIT 1", error_msg=lStr.LAST_UPDATE_NOT_FOUND)
            return False if res[0] in (-1, 0) else str(res[0])
    
    
    ''' Set a new update date.'''
    @staticmethod
    def setUpdateDate(dbHandler):
        if dbHandler.isDBInitOk():
            dt = datetime.now().strftime('%Y%m%d%H%M%S')            
            dbHandler.requestAndCommit("INSERT INTO updates (time) VALUES ('%s')" % dt, error_msg=lStr.REGISTER_UPDATE_ERROR)
            
            
            
    
    @staticmethod
    def acquireLock():
        dbHandler = EpgDbHandler()
        req = "INSERT INTO lock (locked) VALUES (1)"
        dbHandler.requestAndCommit(req)
        dbHandler.close()
    
    
    
    @staticmethod
    def releaseLock():
        dbHandler = EpgDbHandler()
        req = "DELETE FROM lock WHERE 1"
        dbHandler.requestAndCommit(req)
        dbHandler.close()
    
    
    
    @staticmethod
    def isLocked():
        dbHandler = EpgDbHandler()
        req= "SELECT count(*) FROM lock WHERE 1"
        res = dbHandler.fetchOne(req)
        dbHandler.close()    
        return int(res[0]) > 0
    
    
    
    
    
    