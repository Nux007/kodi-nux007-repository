# -*- coding: utf-8 -*-

# -*- coding: utf-8 -*-
import sys, os, xbmc, shutil

from xbmcgui import Dialog
from xbmcaddon import Addon

addon = Addon('plugin.program.super.favourites.xmltv')
path = xbmc.translatePath(addon.getAddonInfo('path'))
sys.path.insert(0, path)

from resources.language import strings
from resources.lib.objects.EpgDb import EpgDbHandler
from resources.lib.helpers import settings
from resources.lib.helpers.logger import SfxLogger

lStr = strings.AddonStrings(addon) 
lSettings = settings.AddonSettings()
aConst = settings.AddonConst()

logger_lib_updaters = SfxLogger("resources.lib.updaters")


# Whole EPG db.
if int(sys.argv[1]) == aConst.ACTION_HARD_RESET:
    
    db    = lSettings.getEpgDbFilePath()
    xml   = lSettings.getEpgXmlFilePath()
    logos = lSettings.getChannelsLogoPath()
    
    if os.path.isfile(db):
        try:
            os.remove(db) 
            if os.path.isfile(db + "-journal"):
                os.remove(db + "-journal")
        except:
            logger_lib_updaters.error("toolbox.py - Error deleting epg database", exc_info=True)
        
    if os.path.isfile(xml):
        os.remove(xml)
    
    if os.path.isdir(logos):
        shutil.rmtree(logos, ignore_errors=True)
    
    if not os.path.isfile(db) and not os.path.isfile(xml):
        Dialog().ok(lStr.DIALOG_TITLE, lStr.HARD_RESET_OK)
    else:
        Dialog().ok(lStr.DIALOG_TITLE, lStr.HARD_RESET_NOK)


# Super favourites folers.
elif int(sys.argv[1]) == aConst.ACTION_SF_FOLDERS:
    
    sf_folder = lSettings.getSFFolder(True)
    for sfpath in os.listdir(sf_folder):
        sfpath = os.path.join(sf_folder, sfpath)
        
        if os.path.isdir(sfpath):
            shutil.rmtree(sfpath, ignore_errors=True)
        else:
            os.remove(sfpath)
            
    Dialog().ok(lStr.DIALOG_TITLE, lStr.HARD_RESET_FOLDERS_OK) 


# Programs reminders.
elif int(sys.argv[1]) == aConst.ACTION_DELETE_REMINDERS:
    dbHandler = EpgDbHandler()
    dbHandler.requestAndCommit("DELETE FROM reminders WHERE 1")
    dbHandler.close()
    Dialog().ok(lStr.DIALOG_TITLE, lStr.HARD_RESET_REMINDERS_OK)
