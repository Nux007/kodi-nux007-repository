# -*- coding: utf-8 -*-
from resources import lStr
import resources.lib.updaters.update as updater
import resources.lib.objects.Reminders as notifier
from resources.lib.helpers.settings import AddonSettings
from resources.lib.objects.EpgDb import EpgDbHandler
from xbmcgui import DialogProgressBG

from resources.lib.helpers.logger import SfxLogger
logger = SfxLogger("resources")
lSettings = AddonSettings()

''' Display the cleanup database progress '''
def cleanupProgress(percent, sender):
    sender.update(int(percent))
    
    if int(percent) >= 100 and not sender is None:
        sender.close()
        

try: 
    # Locking plugin.
    updater.Updates.acquireLock()
    logger.info("Services.py: Lock acquire")
    
    # Cleanup programs even if no update is needed.
    logger.info("Programs cleanup: started")
    dbHandler = EpgDbHandler()
    if not dbHandler.isFirstTimeRuning():
        progress_bar = DialogProgressBG()
        progress_bar.create(lStr.SFX_PROGRAMS_CLEANUP_HEADER, lStr.SFX_PROGRAMS_CLEANUP)
        updater.Updates.getCleanOld(dbHandler, hook=cleanupProgress, sender=progress_bar)
    dbHandler.close()
    logger.info("Programs cleanup: finished")
    
    
    # Update epg source.
    logger.info("EPG updater: started")
    epg_updater = updater.ThreadedEPGUpdater()
    epg_updater.start()
    epg_updater.join()
    logger.info("EPG updater: finished")
    
    
    # Start programs reminders ( notifier ).
    logger.info("Programs notifier: starting")
    epg_notifier = notifier.ThreadedReminderNotifier()
    epg_notifier.start()
    logger.info("Programs notifier: started")
    
    # Release lock.
    updater.Updates.releaseLock()
    logger.info("Services.py: Lock released")
except Exception as e:
    if updater.Updates.isLocked():
        updater.Updates.releaseLock()
        logger.info("Services.py: Lock released")
    logger.error("[ SFX - services.py ] %s", str(e))