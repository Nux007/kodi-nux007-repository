# -*- coding: utf-8 -*-
from xbmcaddon import Addon
from xbmc import translatePath
from os.path import join


addon = Addon('plugin.iptv.list.loader')
DEBUG = True if addon.getSetting('debug.mode') == 'true' else False

MODE_ADDON      = 0
MODE_ADD_SOURCE = 1
MODE_REMOVE_SOURCE = 2

SOURCE_TYPE_URL   = 0
SOURCE_TYPE_LOCAL = 1



''' ============================== '''
'''       Global addon infos       '''
''' ============================== '''


'''
Return the addon path
'''
def getAddonPath(translated=False):
    if not translated:
        return addon.getAddonInfo('path')
    return translatePath(addon.getAddonInfo('path'))


'''
Return the userdata related to the addon.
''' 
def getAddonUserDataPath():
    return getAddonPath(True).replace('addons', join('userdata', 'addon_data'), 1)


'''
Return the epg db file location.
'''
def getDbPath():
    return join(getAddonUserDataPath(), "iptv.db")


'''
Return the addon icon
'''
def getAddonIcon():
    return addon.getAddonInfo('icon')


'''
Return tables structures
'''
def getTablesStructure():
    channels  = "CREATE TABLE channels (id INTEGER PRIMARY KEY AUTOINCREMENT, id_source INTEGER, display_name TEXT, logo TEXT, link TEXT)"
    sources   = "CREATE TABLE sources (id INTEGER PRIMARY KEY AUTOINCREMENT, display_name TEXT, url TEXT, regex Text)"
    
    return channels, sources



''' ============================== '''
'''   Settings from settings.xml   '''
''' ============================== '''


'''
Return true for startup updates.
'''
def doStartupUpdate():
    return True if addon.getSetting('startup.update') == 'true' else False


'''
Return list source type from settings.
'''
def getSourceType():
    return int(addon.getSetting("iptv.source.type"))


'''
Return the source name
'''
def getSourceName():
    return addon.getSetting('iptv.source.name')


'''
Return the local url defined in settings.
'''
def getURLLocal():
    return addon.getSetting('iptv.local.value')


'''
Return the remote url defined in settings.
'''
def getURLRemote():
    return addon.getSetting('iptv.url.value')


'''
Return True if source is compressed.
'''
def isSourceCompressed():
    return True if addon.getSetting('iptv.list.compressed') == 'true' else False


'''
Return True if user want to use regex on html page links
'''
def useRegexPattern():
    return True if addon.getSetting('use.regex') == 'true' else False


'''
Return the regex pattern
'''
def getRegexPattern():
    pattern = addon.getSetting('regex.pattern')
    return pattern if not pattern is None else ""

    
