# -*- coding: utf-8 -*-
from xbmc import executebuiltin, log, LOGERROR
from sqlite3 import connect as SqliteConnect, Error as SqliteError
from os.path import isfile

import urllib

from resources.lib.strings import DIALOG_TITLE, DB_CREATE_TABLES_ERROR, DB_CONNECTION_ERROR 
from resources.lib.settings import getAddonIcon, getTablesStructure, getDbPath

'''
Notify message to the user.
'''
def notify(message, plus=None):
    message = message.encode("utf-8", 'ignore')
    log(message, LOGERROR)
    if not plus is None:
        log(plus, LOGERROR)
        
    executebuiltin('Notification(%s,%s,%s,%s)'%(DIALOG_TITLE.encode("utf-8", 'ignore'), message, 6000, getAddonIcon()))
    


def build_addon_url(query, base_url):
    return base_url + '?' + urllib.urlencode(query)


'''
Database connection.
    '''
def connectIPTVDB():
    
    def connect():
        try:
            database = SqliteConnect(getDbPath())
            database.text_factory = str
            cursor = database.cursor()
        except SqliteError as e:
            notify(DB_CONNECTION_ERROR, e.message)
            return None
        
        return database, cursor
    
    
    if not isfile(getDbPath()):
        database, cursor = connect()
        if database is None:
            return None, None
        
        channels, sources = getTablesStructure()      
        
        try:
            cursor.execute(channels)
            cursor.execute(sources)
            database.commit()
            
        except SqliteError as e:
            notify(DB_CREATE_TABLES_ERROR, e.message)
            return None, None
        return database, cursor

    else:
        return connect() 
    