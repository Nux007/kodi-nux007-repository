# Dev still in progress, do not use it at the moment until a relase / tag is available

# Kodi-Super-Favourites-Xmltv
This plugin provide mapping between Super-favourites + Your iptv legal providers + your xmltv files
