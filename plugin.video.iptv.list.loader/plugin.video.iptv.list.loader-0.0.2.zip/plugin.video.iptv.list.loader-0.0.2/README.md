# Kodi-IPTV-list-loader
Charge vos listes iptv de source légale en un seul emplacement

DEV STILL IN PROGRESS, DO NOT USE UNTIL A RELEASE TAG IS AVAILABLE

Dépends de python-bs4 ( BeautifulSoup ) pour la recherche de liens par regex.
