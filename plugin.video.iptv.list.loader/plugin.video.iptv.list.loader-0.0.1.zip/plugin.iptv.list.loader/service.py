# -*- coding: utf-8 -*-
from resources.lib.settings import doStartupUpdate
from resources.lib.handlers import DatabaseHandler, M3UHandler, SourceFileHandler
from resources.lib.utils import connectIPTVDB, notify
from resources.lib.strings import UPDATE_ERROR
from threading import Thread
from tarfile import is_tarfile
from zipfile import is_zipfile
from os.path import exists


class UpdateLists(Thread):
    
    '''
    Init
    '''
    def __init__(self):
        Thread.__init__(self)
        
    
    '''
    Thread run
    '''
    def run(self):
        database, cursor = connectIPTVDB()
        dbHandler = DatabaseHandler(database, cursor)
        
        sources = dbHandler.getSourcesNames()
        
        for source in sources:
            if not source is None:
                sfile = None
                
                sfhandler = SourceFileHandler(useSettings=False)
                if source["url"].startswith("http"):
                    if source["regex"] is not None and len(source["regex"]) > 0:
                        source["url"] = sfhandler.findM3U(source["regex"], source["url"])
                        
                    sfile = sfhandler.downloadSourceFile(source["url"])
                    
                    if not sfile is None and (is_zipfile(sfile) or is_tarfile(sfile)):
                        sfile = sfhandler.unzip(sfile)
                else:
                    if exists(source["url"]):
                        if not source["url"] is None and (is_zipfile(source["url"]) or is_tarfile(source["url"])):
                            sfile = sfhandler.unzip(source["url"])
                        
                        sfile = sfhandler.copyFileToTmp(source["url"])
                    
                
                if not sfile is None: 
                    m3u = M3UHandler(sfile)
                    if m3u.isM3U():
                        m3u_items = m3u.parse()
                        if len(m3u_items) > 0:
                            result = dbHandler.updateSource(m3u_items, source)
                            if not result:
                                notify(UPDATE_ERROR)

'''
Update entry point
'''
if doStartupUpdate():
    try:
        update = UpdateLists()
        update.start()
    except:
        pass


