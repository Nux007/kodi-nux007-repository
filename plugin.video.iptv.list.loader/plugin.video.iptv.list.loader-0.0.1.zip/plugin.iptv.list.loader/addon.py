# -*- coding: utf-8 -*-
import sys
import xbmc
import xbmcgui
import xbmcplugin
import urlparse
import urllib2

from resources.lib import settings, strings
from resources.lib.handlers import SourceFileHandler, DatabaseHandler, M3UHandler
from resources.lib.utils import notify, connectIPTVDB, build_addon_url


''''''''''''''''''''''''''''''
'''    Plugin entry point  '''
''''''''''''''''''''''''''''''

if __name__ == '__main__':   
    
    # Defining addon mode.
    args = urlparse.parse_qs(sys.argv[2][1:])
    
    mode = int(args.get("add", '0')[0])
    source_mode  = args.get("mode", None)
    
    addon_handle = int(sys.argv[1])
    addon_url    = sys.argv[0]
    
    database, cursor = connectIPTVDB()
    dbHandler = DatabaseHandler(database, cursor)
    
    
    ''' Normal addon mode '''
    if mode == settings.MODE_ADDON:
        ''' Addon normal mode displaying iptv links '''
        xbmcplugin.setContent(addon_handle, 'movies')
        sources = dbHandler.getSourcesNames()
        
        if source_mode is None:
            for source in sources:
                url = build_addon_url({'mode': 'folder', 'id_source':source["id"]}, 
                                      addon_url)
                li = xbmcgui.ListItem(source["display_name"], iconImage='DefaultFolder.png')
                li.addContextMenuItems([('Remove this m3u list', 'RunPlugin(plugin://plugin.iptv.list.loader/?add=2&remove='+str(source["id"])+')',),])
                xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True) 
            xbmcplugin.endOfDirectory(addon_handle)
        
        
        elif source_mode[0] == "folder":
            id_source   = int(args["id_source"][0])
            iptv_links = dbHandler.getIPTVLinks(id_source)

            for iptv in iptv_links:
                urlb = build_addon_url({"mode":'playurl', 'id':iptv["id"]}, addon_url)
                li = xbmcgui.ListItem(iptv["display_name"], iconImage=iptv["logo"])
                xbmcplugin.addDirectoryItem(handle=addon_handle, url=urlb, listitem=li, isFolder=True)            
            xbmcplugin.endOfDirectory(addon_handle)
        
        
        elif source_mode[0] == 'playurl':
            data = dbHandler.getIptvData(int(args["id"][0]))
            link = data["link"]
            
            try:
                req = urllib2.Request(link, headers={ 'User-Agent': 'Mozilla/5.0' })
                r = urllib2.urlopen(req)
                link = r.geturl()   
                r.close()
                
            except:
                link = data["link"]

            if link.endswith((".ts", ".2ts")) or link.find(".ts?") > 0 or link.find(".2ts?") > 0:
                link = "plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&url="+ link + "&name;=test"
                xbmc.executebuiltin('XBMC.RunPlugin(' + link + ')')
            else:     
                xbmc.Player().play(link)  
        
        del database
        del cursor          
        
        
        
    elif mode == settings.MODE_ADD_SOURCE:
        sourceHandler = SourceFileHandler()
        path = sourceHandler.getSourceFile()
        
        if path is None:
            notify(strings.CONFIGURATION_ERROR)
        else:
            m3u = M3UHandler(path)
            if m3u.isM3U():
                m3u_items = m3u.parse()
                if len(m3u_items) > 0:
                    database, cursor = connectIPTVDB()
                    dbHandler = DatabaseHandler(database, cursor)
                    result = dbHandler.addSources(m3u_items, sourceHandler.getSourceName(), 
                                                  sourceHandler.getSourceURL(), sourceHandler.getSourceRegex())
                    
                    if result:
                        notify(strings.SOURCE_ADDED)
                    else:
                        notify(strings.SOURCE_NOT_ADDED)
            else:
                notify(strings.BAD_M3U_FILE)
                
                
    elif mode == settings.MODE_REMOVE_SOURCE:
        source = args.get("remove", None)
        
        if not source is None:
            if dbHandler.removeSource(int(source[0])):
                xbmc.executebuiltin("Container.Refresh")
                notify(strings.SOURCE_REMOVED)
    
    