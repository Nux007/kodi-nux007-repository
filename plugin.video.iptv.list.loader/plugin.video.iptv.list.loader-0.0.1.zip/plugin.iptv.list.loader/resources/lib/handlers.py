# -*- coding: utf-8 -*-
from os.path import join, isdir, isfile, exists
from os import remove, rename
from glob import glob
from urllib2 import urlopen, HTTPError, Request
from shutil import rmtree
from zipfile import is_zipfile, ZipFile, BadZipfile, LargeZipFile
from tarfile import is_tarfile, TarFile, ReadError as TarReadError
from sqlite3 import Error as SqliteError

from resources.lib import settings, strings 
from resources.lib.utils import notify
import ssl
 
'''
Handle sources downloads / moves / renames ...
'''
class SourceFileHandler(object):
    
    path = None
    source = None
    
    ''' Init handler object '''
    def __init__(self, useSettings=True):
        self.useSettings = useSettings
        
        if self.useSettings:
            source_type = settings.getSourceType()
            
            if source_type == settings.SOURCE_TYPE_LOCAL:
                self.source = settings.getURLLocal()
                if not self.source is None and self.source != "":
                    self.path = self.copyFileToTmp(self.source)
                    
            else:
                self.source = settings.getURLRemote()  
                if not self.source is None and self.source != "":
                    self.path = self.downloadSourceFile(self.source)
                
    
    ''' Return the source file once all jobs are done '''           
    def getSourceFile(self):
        return self.path
    
    
    ''' Return the source URL '''
    def getSourceURL(self):
        return self.source
                
    
    
    ''' Download the source '''
    def downloadSourceFile(self, source):
        
        ssl._create_default_https_context = ssl._create_unverified_context
        
        dest_file = join(settings.getAddonUserDataPath(), "iptv_temp.m3u") 
        
        if settings.useRegexPattern() and self.useSettings:
            pattern = settings.getRegexPattern()
            if not pattern is None and len(pattern) > 0:
                source = self.findM3U(pattern, source) 
                if source is None: 
                    notify(strings.REGEX_NOT_FOUND)  
        
        try:
            if not source is None:
                req = Request(source, headers={ 'User-Agent': 'Mozilla/5.0' })
                download = urlopen(req, timeout=30)
                
                if isfile(dest_file):
                    remove(dest_file)
            
                tsf = open(dest_file, "w")
                tsf.write(download.read())
                tsf.close()
                del tsf
                
                if settings.isSourceCompressed() and self.useSettings:
                    dest_file = self.unzip(dest_file)
                            
                if exists(dest_file):
                    return dest_file
                            
        except HTTPError as e:
            if self.useSettings:
                notify(strings.DOWNLOAD_ERROR, e.reason)
        
        return None
    
    
    ''' Search for pattern into html page links '''
    def findM3U(self, pattern, url):
        try:
            from bs4 import BeautifulSoup
            from re import compile
            
            ssl._create_default_https_context = ssl._create_unverified_context
            
            req = Request(url, headers={ 'User-Agent': 'Mozilla/5.0' })
            response = urlopen(req)
            soup = BeautifulSoup(response.read(), 'html.parser')
            
            regex = compile(pattern)
            for link in soup.findAll('a'):
                if link.get('href') != "#":
                    if regex.search(str(link)) is not None:
                        return link.get("href")
            return None
        
        except (ImportError, AttributeError):
            return None
    
    
    

    ''' Unzip a given file '''
    def unzip(self, source):
        dest = join(settings.getAddonUserDataPath(), "iptv.archive")
        dest_file = join(settings.getAddonUserDataPath(), "iptv_temp.m3u") 
            
        if is_zipfile(source):
            try:
                with ZipFile(source, "r") as xmltv_zip:
                    xmltv_zip.extractall(dest)
                    xmltv_zip.close()
                    
            except BadZipfile, LargeZipFile:
                if isdir(dest):
                    rmtree(dest)
                notify(strings.ARCHIVE_ZIP_UNCOMPRESS_ERROR)
                return None
            
        elif is_tarfile(source):
                try:
                    with TarFile(source) as xmltv_tar:
                        xmltv_tar.extractall(dest)
                        xmltv_tar.close()
                        
                except TarReadError:
                    if isdir(dest):
                        rmtree(dest)
                    notify(strings.ARCHIVE_TAR_UNCOMPRESS_ERROR)
                    return None
        else:
            notify(strings.ARCHIVE_UNSUPPORTED_FORMAT)
            return None
        
        if not dest is None:
            paths = glob(join(dest, "*.m3u"))
                
            if len(paths) <= 0:
                notify(strings.CONFIGURATION_ERROR)
                rmtree(dest)
                return None
            else:
                for ptest in paths:
                    rename(ptest, dest_file)
                rmtree(dest)
        
        return dest_file if isfile(dest_file) else None
    
    
    ''' Copy source to working folder. '''
    def copyFileToTmp(self, source):
        
        if settings.isSourceCompressed() and self.useSettings:
            source = self.unzip(source)
        
        source = open(source, "rb")
        dest_file   = join(settings.getAddonUserDataPath(), "iptv_temp.m3u")
        
        if isfile(dest_file):
            remove(dest_file)
            
        dest = open(dest_file, "wb")
        
        while 1:
            copy_buffer = source.read(1024*1024)
            if not copy_buffer:
                break
            dest.write(copy_buffer)
                
        return dest_file
    
    
    ''' Return the source name '''
    def getSourceName(self):
        return settings.getSourceName() if settings.getSourceName() != "" else None
    
    
    ''' Return regex pattern if any '''
    def getSourceRegex(self):
        if settings.useRegexPattern():
            return settings.getRegexPattern()
        return ""



'''
Handle sources database data
'''
class DatabaseHandler(object):
    
    database = cursor = None
    
    ''' Init '''
    def __init__(self, database, cursor):
        self.database = database
        self.cursor = cursor
    
    
    def addSources(self, items_list, source_name, source_url, regex=""):
        check = 'SELECT count(*) FROM sources WHERE (display_name) = "%s"' % source_name
        self.cursor.execute(check)
        
        if int(self.cursor.fetchone()[0]) <= 0:
            try:   
                source_request = 'INSERT INTO sources (display_name, url, regex) VALUES ("%s", "%s", "%s")' % (source_name, source_url, regex)
                self.cursor.execute(source_request)
                self.database.commit()
            
                id_request = 'SELECT id FROM sources WHERE (display_name) = "%s"' % source_name
                self.cursor.execute(id_request)
                id_source = int(self.cursor.fetchone()[0])
                
                insert_request = "INSERT INTO channels (id_source, display_name, logo, link) VALUES (?,?,?,?)"
                data = []
                for item in items_list:
                    if len(item["channel"]) > 0:
                        data.append((id_source, item["channel"], item["logo"], item["link"]))
                self.cursor.executemany(insert_request, data)
                self.database.commit()
            except SqliteError:
                return False
            return True
        else:
            notify(strings.SOURCE_NAME_EXISTS)
            return False
        
        
    ''' Remove a source from DB '''
    def removeSource(self, id_source):
        check = 'SELECT count(*) FROM sources WHERE (id) = "%s"' % id_source
        self.cursor.execute(check)
        
        if int(self.cursor.fetchone()[0]) > 0:
            try:
                source_remove = "DELETE FROM sources WHERE id=%i" % id_source
                channels_remove = "DELETE FROM channels WHERE id_source=%i" % id_source
                self.cursor.execute(source_remove)
                self.cursor.execute(channels_remove)
                self.database.commit()
            except SqliteError:
                return False
            return True
        
        
    ''' Update a source '''
    def updateSource(self, m3u_items, source):
        try:
            delete = 'DELETE FROM channels WHERE id_source = %i' % source["id"]                    
            self.cursor.execute(delete)
            data = []
            for item in m3u_items:
                data.append((int(source["id"]), item["channel"], item["logo"], item["link"]))
                 
            request = 'INSERT INTO channels (id_source, display_name, logo, link) VALUES (?,?,?,?)' 
                    
            self.cursor.executemany(request, data)
            self.database.commit()
        except:
            return False
        return True
        
        
        
        
    ''' Return sources names '''
    def getSourcesNames(self):
        request = "SELECT * FROM sources ORDER BY id ASC"
        sources = []
        for source in self.cursor.execute(request):
            sources.append({"id": source[0], "display_name": source[1], "url": source[2], "regex": source[3]})
    
        return sources
    
    
    
    ''' Return all iptv links for the given source id '''
    def getIPTVLinks(self, id_source):
        request = "SELECT * FROM channels WHERE id_source=%i" % id_source
        channels = []
        for channel in self.cursor.execute(request):
            channels.append({"id": channel[0], "display_name": channel[2], 
                             "logo": channel[3], "link": channel[4]})
        return channels
    
    
    ''' Return one iptv link data '''
    def getIptvData(self, id_row):
        request = "SELECT * FROM channels WHERE id=%i" % id_row
        self.cursor.execute(request)
        channel = self.cursor.fetchone()
        
        return {"id": channel[0], "display_name": channel[2], 
                "logo": channel[3], "link": channel[4]}
    
    
''' 
M3U file handler
'''
class M3UHandler(object):
    
    ''' Init '''
    def __init__(self, m3u):
        self.m3u = m3u
    
    
    
    ''' Return the m3u file path '''
    def getM3UPath(self):
        return self.m3u
    
    
    ''' Return True if provided file is realy an mu3 '''
    def isM3U(self):
        ret = False
        if exists(self.m3u):
            m3u_file = open(self.m3u, "r")
            test = m3u_file.readline()
            
            if test.find(r'EXTM3U') > 0 or test.find(r'EXTINF') > 0 :
                ret = True
            m3u_file.close()
            del m3u_file
        return ret
    
    
    
    ''' Parse the m3u and return a list of items. '''
    def parse(self):
        iptv_items = []
        
        with open(self.m3u) as m3u_file:
            lines = m3u_file.readlines()
        
        iptv = {"channel": "", "link": "", "logo": ""}
        for line in lines:
            
            if line != "" and line.find("EXTM3U") <= 0:
                
                if line.find("EXTINF") > 0:
                    
                    if line.find("tvg-name") <= 0:
                        iptv["channel"] = line[line.rfind(",") + 1 :].rstrip("\n\r")
                    
                    else:
                        idx = line.find("tvg-name=") + len("tvg-name=") + 1
                        tvg_name = line[idx:]
                        idx = tvg_name.find('"') if tvg_name.find('"') > 0 else tvg_name.find("'") if tvg_name.find("'") > 0 else None 
                        iptv["channel"] = tvg_name[:idx].rstrip("\n\r")
                    
                    if line.find("tvg-logo") > 0:
                        idx = line.find("tvg-logo=") + len("tvg-logo=") + 1
                        tvg_logo = line[idx:]
                        idx = tvg_logo.find('"') if tvg_logo.find('"') > 0 else tvg_logo.find("'") if tvg_logo.find("'") > 0 else None 
                        iptv["logo"] = tvg_logo[:idx].rstrip("\n\r")    
                else:
                    if not iptv["channel"] is None:
                        iptv["link"] = line.rstrip("\n\r")
                        iptv_items.append(iptv)
                    iptv = {"channel": "", "link": "", "logo": ""}
                
        return iptv_items
    
       
    
