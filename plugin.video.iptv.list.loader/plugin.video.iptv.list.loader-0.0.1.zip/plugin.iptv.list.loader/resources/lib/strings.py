# -*- coding: utf-8 -*-
try:
    from resources.lib import settings as plugin
except ImportError:
    import settings as plugin
    
    
DIALOG_TITLE                 = plugin.addon.getLocalizedString(8001)
ARCHIVE_UNSUPPORTED_FORMAT   = plugin.addon.getLocalizedString(8002)
ARCHIVE_ZIP_UNCOMPRESS_ERROR = plugin.addon.getLocalizedString(8003)
ARCHIVE_TAR_UNCOMPRESS_ERROR = plugin.addon.getLocalizedString(8004)
DOWNLOAD_ERROR               = plugin.addon.getLocalizedString(8005)
CONFIGURATION_ERROR          = plugin.addon.getLocalizedString(8006)

DB_CONNECTION_ERROR          = plugin.addon.getLocalizedString(8007)
DB_CREATE_TABLES_ERROR       = plugin.addon.getLocalizedString(8008)
BAD_M3U_FILE                 = plugin.addon.getLocalizedString(8009)
SOURCE_NAME_EXISTS           = plugin.addon.getLocalizedString(8010)
SOURCE_ADDED                 = plugin.addon.getLocalizedString(8011)
SOURCE_NOT_ADDED             = plugin.addon.getLocalizedString(8012)
TIMEOUT_MESSAGE              = plugin.addon.getLocalizedString(8013)
SOURCE_REMOVED               = plugin.addon.getLocalizedString(8014)
UPDATE_ERROR                 = plugin.addon.getLocalizedString(8015)
REGEX_NOT_FOUND              = plugin.addon.getLocalizedString(8016)